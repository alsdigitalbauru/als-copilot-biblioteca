"""
O RESUMO DO FUNIL (story 42.1) — a porta. O código mora em `resumo_do_funil/`, um arquivo por função:

    constantes.py   os tetos, os prazos e os padrões dos campos (o teste confere com o automacao.yaml)
    relogio.py      a hora de São Paulo (trocável no teste)
    textos.py       o que a automação diz: R$, datas, listas com "e mais N", o corte do texto
    periodo.py      a frequência: o dia de mandar, o período lido, o título
    tipo.py         os grupos de negócio (o campo tipos_de_negocio) e a pista que decide cada um
    leitura.py      TODO o SQL (só SELECT): o período, a frente e o detalhe dos clientes
    fatos.py        os números do período, a partir do que a leitura trouxe (sem banco, sem IA)
    quer.py         uma linha por cliente com o que ele procura (sem IA)
    texto.py        os blocos do resumo, e o encolhimento do bloco do cliente no teto
    fixas.py        as sugestões do código (quando a IA não fala)
    sugestoes.py    as sugestões da IA: o ÚNICO arquivo que chama a IA
    avisos.py       o aviso à ALS quando a leitura quebra
    rodada.py       a rodada inteira
"""

from __future__ import annotations

from resumo_do_funil.rodada import rodar


async def executar(contexto):
    return await rodar(contexto)
