"""
AS SUGESTÕES DO CÓDIGO (story 42.1) — as fixas, cada uma com o número que a sustenta. Valem quando a IA não fala
(ou quando não houve movimento). Sem IA: só conta o que o funil já mostra.
"""

from __future__ import annotations

from typing import Any

from . import constantes, periodo, textos, tipo


def sugestoes_fixas(f: dict[str, Any]) -> list[str]:
    candidatas = [
        _retomar(f),
        _cobrar(f),
        _atribuir(f),
        _confirmar(f),
        _responder(f),
        _proxima_acao(f),
    ]
    return [s for s in candidatas if s][: constantes.MAXIMO_DE_SUGESTOES]


def _retomar(f: dict[str, Any]) -> str | None:
    if not f["negociacao_parada"]:
        return None
    n = len(f["negociacao_parada"])
    contagem = tipo.contagem([x["tipo"] for x in f["negociacao_parada"]], f["grupos"])
    sufixo = f" ({contagem})" if contagem else ""
    return (
        f"Retome já os {n} negócio(s) em negociação sem contato há {constantes.DIAS_SEM_CONTATO}+ dias{sufixo}: "
        "são os mais perto de fechar."
    )


def _cobrar(f: dict[str, Any]) -> str | None:
    if not f["vencidas"]:
        return None
    nome, quantos = textos.por_responsavel(f["vencidas"]).most_common(1)[0]
    return f"Cobre as {len(f['vencidas'])} próximas ações vencidas, começando por {nome} ({quantos})."


def _atribuir(f: dict[str, Any]) -> str | None:
    if not f["ninguem"]:
        return None
    return f"Defina já quem atende os {len(f['ninguem'])} contato(s) que ninguém assumiu."


def _confirmar(f: dict[str, Any]) -> str | None:
    if not f["visitas_de_amanha"]:
        return None
    return f"Confirme com os clientes as {len(f['visitas_de_amanha'])} visita(s) {periodo.de_frente(f['frequencia'])}."


def _responder(f: dict[str, Any]) -> str | None:
    if not f["esperando"]:
        return None
    return f"Responda os {len(f['esperando'])} cliente(s) que esperam há 1 h ou mais."


def _proxima_acao(f: dict[str, Any]) -> str | None:
    if not f["sem_proxima"]:
        return None
    return f"Dê uma próxima ação com data aos {len(f['sem_proxima'])} negócio(s) abertos que não têm."
