"""
O QUE A AUTOMAÇÃO DIZ (story 42.1) — dinheiro, datas, nomes, listas e o texto que vem do cliente, já limpo. Sem IA: o
que não foi registrado não se inventa.
"""

from __future__ import annotations

import re
import unicodedata
from collections import Counter
from datetime import datetime
from typing import Any

from . import constantes
from .relogio import FUSO

DIAS_DA_SEMANA = ("segunda", "terça", "quarta", "quinta", "sexta", "sábado", "domingo")
MESES = ("janeiro", "fevereiro", "março", "abril", "maio", "junho",
         "julho", "agosto", "setembro", "outubro", "novembro", "dezembro")
AGENTE = "o agente"
_REAIS = re.compile(r"(?:\b(até|de|a partir de|acima de)\s+)?(R\$\s?\d[\d.,]*(?:\s?(?:mil|milhão|milhões))?)", re.IGNORECASE)
_EMAIL = re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")
_TELEFONE = re.compile(r"\+?\d(?:[ ()-]?\d){9,}")
_ROTULO_DE_CONTATO = re.compile(r"(?i)\b(e-?mail|telefone|celular|whatsapp)\b\s*:?\s*")
_PEDIDO = re.compile(r"(?im)^\s*\**\s*pedido\s*:.*$")
_SOBRA = re.compile(r"(\s*,)+\s*(?=$|,)")


def sem_acento(texto: Any) -> str:
    normal = unicodedata.normalize("NFKD", str(texto or ""))
    return "".join(c for c in normal if not unicodedata.combining(c)).lower()


def palavras(texto: Any) -> list[str]:
    """As palavras de um campo, uma por linha, sem acento e sem maiúscula."""
    return [sem_acento(linha).strip() for linha in str(texto or "").splitlines() if linha.strip()]


def pares(texto: Any) -> list[tuple[str, str]]:
    """Cada palavra de um campo como o dono escreveu, e a mesma sem acento e sem maiúscula (para achar e para mostrar)."""
    return [(linha.strip(), sem_acento(linha).strip()) for linha in str(texto or "").splitlines() if linha.strip()]


def tem(texto: Any, lista: list[str]) -> bool:
    alvo = sem_acento(texto)
    return any(palavra in alvo for palavra in lista)


def campo(campos: dict[str, Any], nome: str, padrao: str) -> str:
    """O valor de um campo do pacote; sem o campo (ou nulo), o padrão. Vazio é valor: desliga o que depende dele."""
    valor = campos.get(nome)
    return padrao if valor is None else str(valor)


def ligado(valor: Any) -> bool:
    return valor is not False


def reais(centavos: int) -> str:
    """R$ no jeito do Brasil: R$ 1.234,56."""
    inteiro, resto = divmod(int(round(centavos)), 100)
    return f"R$ {inteiro:,}".replace(",", ".") + f",{resto:02d}"


def hora(instante: datetime | None) -> str:
    return instante.astimezone(FUSO).strftime("%H:%M") if instante else ""


def dia(instante: datetime | None) -> str:
    return instante.astimezone(FUSO).strftime("%d/%m") if instante else ""


def intervalo(inicio: datetime, fim: datetime) -> str:
    return f"{dia(inicio)} a {dia(fim)}"


def rotulo_do_mes(instante: datetime) -> str:
    local = instante.astimezone(FUSO)
    return f"{MESES[local.month - 1]}/{local.year}"


def dia_da_semana(instante: datetime) -> str:
    local = instante.astimezone(FUSO)
    return f"{DIAS_DA_SEMANA[local.weekday()]}, {local.strftime('%d/%m')}"


def quem(nome: Any) -> str:
    return str(nome).strip() if nome and str(nome).strip() else AGENTE


def por_responsavel(itens: list[dict[str, Any]]) -> Counter[str]:
    return Counter(quem(item.get("responsavel")) for item in itens)


def trecho(texto: Any, maximo: int = constantes.TRECHO) -> str:
    linha = " ".join(str(texto or "").replace("*", "").split())
    return linha if len(linha) <= maximo else linha[: maximo - 1].rstrip() + "…"


def sem_contato(texto: Any) -> str:
    """O texto sem e-mail, telefone nem o rótulo que os introduz: o que o cliente escreveu, sem os dados dele."""
    limpo = _EMAIL.sub("", str(texto or ""))
    limpo = _TELEFONE.sub("", limpo)
    limpo = " ".join(_ROTULO_DE_CONTATO.sub("", limpo).split())
    return _SOBRA.sub("", limpo).strip(" ,;:-")


def sem_pedido(texto: Any) -> str:
    """O texto sem as linhas de roteamento ("**Pedido:** X assumiu…"): o que o cliente pediu é o resto."""
    return _PEDIDO.sub("", str(texto or ""))


def extrair_reais(texto: Any) -> list[str]:
    """Os R$ que o cliente citou, como foram escritos ("até R$ 500 mil"): sem somar e sem converter."""
    saida = []
    for achado in _REAIS.finditer(" ".join(str(texto or "").split())):
        valor = achado.group(2).rstrip(".,")
        saida.append(f"{achado.group(1)} {valor}" if achado.group(1) else valor)
    return saida


def vezes(contagem: dict[str, int]) -> str:
    """{"Ana": 3, "Beto": 1} → "Ana 3, Beto 1" (do maior para o menor)."""
    return ", ".join(f"{nome} {n}" for nome, n in sorted(contagem.items(), key=lambda par: (-par[1], par[0])))


def lista(linhas: list[str], maximo: int = constantes.LINHAS_POR_BLOCO) -> list[str]:
    """As linhas "- …" de um bloco, com "e mais N" quando passa do teto."""
    saida = [f"- {linha}" for linha in linhas[:maximo]]
    if len(linhas) > maximo:
        saida.append(f"- e mais {len(linhas) - maximo}")
    return saida


def bloco(titulo: str, linhas: list[str]) -> str:
    return "\n".join([titulo, *linhas])


def cortar(texto: str, maximo: int) -> str:
    """O texto inteiro até o teto, cortado no fim de uma linha."""
    if len(texto) <= maximo:
        return texto
    cortado = texto[: maximo - 2]
    return cortado[: cortado.rfind("\n")].rstrip() + "\n…"
