"""
A RODADA (story 42.1): ler, contar, (no máximo) uma pergunta à IA, uma mensagem ao dono.

    horário (20h)        só manda no dia de mandar da frequência (diária: todo dia; semanal e mensal: um dia)
    "Rodar agora"        manda na hora, com o período da frequência, e não grava o envio do dia (o agendado ainda sai)
    o de hoje já saiu    a rodada de horário termina sem ler nada (a tela pode rodar mais vezes)
    a leitura quebrou    avisa a ALS, um aviso por problema; o dono não recebe resumo pela metade
"""

from __future__ import annotations

from typing import Any

from . import avisos, constantes, fatos, fixas, leitura, periodo, quer, relogio, sugestoes, texto, textos
from .relogio import FUSO

ESPACO_DA_MENSAGEM = constantes.MAXIMO_DO_TEXTO - constantes.MAXIMO_DAS_SUGESTOES - 60


async def rodar(contexto) -> dict[str, Any]:
    agora = relogio.agora()
    campos = contexto.campos
    hoje = agora.astimezone(FUSO).date().isoformat()
    if contexto.gatilho != "manual":
        parada = await _parar_se_nao_for_hora(contexto, agora, hoje)
        if parada:
            return parada
    freq = periodo.frequencia(campos)
    try:
        dados = await leitura.ler(contexto, periodo.inicio_do_periodo(agora, freq), agora,
                                  periodo.fim_da_frente(agora, freq))
    except Exception as erro:  # noqa: BLE001 — o dono não recebe resumo pela metade; a ALS é avisada
        return await _erro_de_leitura(contexto, erro)
    f = fatos.fatos(dados, campos, agora)
    quer_ligado = textos.ligado(campos.get("quer_de_cada_cliente", True))
    if quer_ligado:
        await _ler_o_que_cada_um_quer(contexto, f, campos)
    mensagem, da_ia = await _mensagem(contexto, f, campos, quer_ligado)
    try:
        await contexto.avisar(mensagem, titulo=periodo.titulo(agora, freq), na_conversa=True)
    except Exception as erro:  # noqa: BLE001
        contexto.registrar(f"o resumo não saiu: {erro}")
        await avisos.tratar(contexto, {"aviso": str(erro)[:300]}, rodada_completa=False)
        return {"situacao": "erro", "resumo": f"O resumo não chegou ao dono: {erro}"}
    if contexto.gatilho != "manual":
        await _marcar_envio(contexto, hoje)
    await avisos.tratar(contexto, {}, rodada_completa=True)
    return {"situacao": "ok", "resumo": _resumo_da_rodada(f, da_ia)}


async def _parar_se_nao_for_hora(contexto, agora, hoje: str) -> dict[str, Any] | None:
    """A rodada de horário que não tem o que fazer hoje termina sem ler nada (e deixa uma linha no registro)."""
    if not periodo.eh_dia_de_mandar(agora, contexto.campos):
        motivo = periodo.motivo_de_pular(contexto.campos)
        contexto.registrar(motivo)
        return {"situacao": "ok", "resumo": f"{motivo[0].upper()}{motivo[1:]}."}
    estado = await contexto.estado.ler()
    if estado.get("enviado_em") == hoje:
        return {"situacao": "ok", "resumo": "O resumo de hoje já saiu; nada a fazer até amanhã."}
    return None


async def _erro_de_leitura(contexto, erro: Exception) -> dict[str, Any]:
    contexto.registrar(f"a leitura do banco parou: {erro}")
    await avisos.tratar(contexto, {"leitura": str(erro)[:300]}, rodada_completa=False)
    return {"situacao": "erro", "resumo": f"Não consegui ler o funil: {erro}"}


async def _ler_o_que_cada_um_quer(contexto, f: dict[str, Any], campos: dict[str, Any]) -> None:
    """O detalhe dos clientes que entram no bloco. Se falhar, o bloco diz isso e o resto do resumo sai."""
    f["quer_falhou"] = False
    detalhes = quer.sem_detalhe()
    try:
        detalhes = await leitura.ler_detalhe(contexto, quer.candidatos(f))
    except Exception as erro:  # noqa: BLE001 — a falha do detalhe não derruba o resumo
        contexto.registrar(f"o que cada cliente quer não foi lido: {erro}")
        f["quer_falhou"] = True
    f["clientes"] = quer.clientes(f, detalhes, campos)


async def _mensagem(contexto, f: dict[str, Any], campos: dict[str, Any], quer_ligado: bool) -> tuple[str, bool]:
    """A mensagem ao dono, com as sugestões (da IA, uma vez, ou as fixas). Devolve também se a IA falou."""
    lista_da_ia: list[str] = []
    if fatos.houve_movimento(f) and textos.ligado(campos.get("sugestoes_da_ia")):
        resumo_para_ia = texto.montar(f, campos, ESPACO_DA_MENSAGEM, com_clientes=False)
        objetivo = textos.campo(campos, "objetivo_das_sugestoes", constantes.OBJETIVO_DAS_SUGESTOES)
        lista_da_ia = await sugestoes.da_ia(contexto, resumo_para_ia, objetivo)
    sugeridas = lista_da_ia or fixas.sugestoes_fixas(f)
    partes = [texto.montar(f, campos, ESPACO_DA_MENSAGEM, com_clientes=quer_ligado)]
    if sugeridas:
        partes.append(textos.bloco("💡 **Sugestões para fechar mais**", [f"- {s}" for s in sugeridas]))
    return textos.cortar("\n\n".join(partes), constantes.MAXIMO_DO_TEXTO), bool(lista_da_ia)


async def _marcar_envio(contexto, hoje: str) -> None:
    estado = await contexto.estado.ler()
    estado["enviado_em"] = hoje
    await contexto.estado.gravar(estado)


def _resumo_da_rodada(f: dict[str, Any], da_ia: bool) -> str:
    origem = "da IA" if da_ia else "fixas"
    sem_movimento = "" if fatos.houve_movimento(f) else "; dia sem movimento, sem IA"
    return (
        f"Resumo enviado: {len(f['leads'])} contato(s) novo(s), {len(f['mudancas'])} mudança(s) de fase, "
        f"{len(f['ganhos'])} fechamento(s), {len(f['perdidos'])} perda(s); sugestões {origem}{sem_movimento}."
    )
