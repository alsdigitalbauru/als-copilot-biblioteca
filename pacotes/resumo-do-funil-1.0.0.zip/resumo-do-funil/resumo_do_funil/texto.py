"""
O TEXTO DO RESUMO (story 42.1) — os blocos, na ordem, e o encolhimento do bloco "o que cada cliente quer" quando o
texto passa do teto. Ele é o primeiro a encolher; o resto nunca é cortado por causa dele.
"""

from __future__ import annotations

from collections import Counter
from typing import Any

from . import constantes, fatos, periodo, quer, textos, tipo
from .textos import bloco, lista, quem, trecho


def montar(f: dict[str, Any], campos: dict[str, Any], teto: int, com_clientes: bool = True) -> str:
    """O resumo inteiro até o teto: o bloco do cliente encolhe primeiro; por último, o corte no fim de uma linha."""
    texto = ""
    for maximo in range(quer.maximo(campos), -1, -1):
        do_cliente = quer.bloco(f, maximo) if com_clientes else ""
        texto = _juntar(_partes(f, do_cliente))
        cabe = len(texto) <= teto and len(do_cliente) <= constantes.MAXIMO_DO_QUE_QUER
        if not com_clientes or maximo == 0 or cabe:
            break
    return textos.cortar(texto, teto)


def _juntar(partes: list[str]) -> str:
    return "\n\n".join(p for p in partes if p)


def _partes(f: dict[str, Any], do_cliente: str) -> list[str]:
    if fatos.houve_movimento(f):
        dia = [_contatos(f), do_cliente, *_do_dia(f)]
    else:
        dia = [_sem_movimento(f)]
    return [_cabeca(f), *dia, _amanha(f), _funil(f), _gargalos(f)]


def _do_dia(f: dict[str, Any]) -> list[str]:
    return [_atendimentos(f), _distribuicao(f), _fases(f), _visitas(f), _propostas(f), _fechamentos(f), _tarefas(f)]


def _cabeca(f: dict[str, Any]) -> str:
    return f"🌙 **{f['titulo']}** (registros de {periodo.desde(f['agora'], f['frequencia'])} até {textos.hora(f['agora'])})"


def _sem_movimento(f: dict[str, Any]) -> str:
    return f"{periodo.quando(f['frequencia']).capitalize()} não houve nenhum registro novo no funil, no atendimento nem nas tarefas."


def _negocio(n: dict[str, Any]) -> str:
    nome = n.get("contato") or n.get("titulo") or "sem nome"
    return f"{nome} ({quem(n.get('responsavel'))})"


def _com_tipos(f: dict[str, Any], numero: int, tipos: list[str]) -> str:
    contagem = tipo.contagem(tipos, f["grupos"])
    return f"{numero} ({contagem})" if numero and contagem else str(numero)


def _contatos(f: dict[str, Any]) -> str:
    q = periodo.quando(f["frequencia"])
    linhas = []
    if f["leads"]:
        origens = Counter(str(lead["origem"] or "sem origem") for lead in f["leads"])
        linhas.append(f"Por origem: {textos.vezes(dict(origens))}")
        tipos_dos_leads = tipo.contagem(f["tipos_dos_leads"], f["grupos"])
        if tipos_dos_leads:
            linhas.append(f"Tipo: {tipos_dos_leads}")
    else:
        linhas.append(f"Nenhum contato novo registrado {q}")
    return bloco(f"📥 **Contatos novos: {len(f['leads'])}**", [f"- {l}" for l in linhas])


def _atendimentos(f: dict[str, Any]) -> str:
    linhas = []
    if f["novas"]:
        canais = Counter(str(c["canal"] or "outro") for c in f["novas"])
        linhas.append(f"Conversas novas: {len(f['novas'])} ({textos.vezes(dict(canais))})")
    if f["do_cliente_hoje"]:
        linhas.append(f"Mensagens de clientes: {f['do_cliente_hoje']}, em {f['conversas_com_cliente_hoje']} conversa(s)")
    if f["da_equipe_hoje"]:
        linhas.append(f"Mensagens da equipe aos clientes: {f['da_equipe_hoje']}")
    if f["respostas"]:
        linhas.append(f"Retornos da equipe registrados: {textos.vezes(dict(f['respostas']))}")
    vazio = f"Nenhum atendimento registrado {periodo.quando(f['frequencia'])}"
    return bloco("💬 **Atendimentos**", [f"- {l}" for l in linhas] or [f"- {vazio}"])


def _distribuicao(f: dict[str, Any]) -> str:
    linhas = []
    if f["passagens"]:
        destinos = Counter(str(p["destino_rotulo"] or "sem destino") for p in f["passagens"])
        linhas.append(f"Atendimentos passados: {len(f['passagens'])} ({textos.vezes(dict(destinos))})")
        pessoas = [p for passagem in f["passagens"] for p in (passagem["pessoas"] or [])]
        foram = sum(1 for p in pessoas if p.get("foi"))
        if pessoas:
            linhas.append(f"Foram falar com o cliente: {foram} de {len(pessoas)} pessoa(s) chamada(s)")
    if f["ninguem"]:
        nomes = ", ".join(str(o["contato"] or "sem nome") for o in f["ninguem"][: constantes.LINHAS_POR_BLOCO])
        linhas.append(f"⚠️ Ninguém assumiu e segue sem responsável: {len(f['ninguem'])} — {nomes}")
    vazio = f"Nenhuma passagem de atendimento {periodo.quando(f['frequencia'])}"
    return bloco("🤝 **Distribuição**", [f"- {l}" for l in linhas] or [f"- {vazio}"])


def _fases(f: dict[str, Any]) -> str:
    if not (f["mudancas"] or f["negocios_novos"]):
        return ""
    linhas = []
    if f["negocios_novos"]:
        linhas.append(f"Negócios novos no funil: {len(f['negocios_novos'])}")
    por_fase: dict[str, list[str]] = {}
    for destino, de_tipo in f["mudancas"]:
        por_fase.setdefault(destino, []).append(de_tipo)
    for destino, tipos in sorted(por_fase.items(), key=lambda par: -len(par[1])):
        linhas.append(f"Para {destino}: {_com_tipos(f, len(tipos), tipos)}")
    return bloco(f"🔀 **Mudanças de fase: {len(f['mudancas'])}**", lista(linhas, maximo=8))


def _visitas(f: dict[str, Any]) -> str:
    if not f["palavras"]["visita"]:
        return ""
    linhas = []
    if f["para_visita"]:
        nomes = ", ".join(_negocio(n) for n in f["para_visita"][:4])
        linhas.append(f"Entraram em fase de visita: {len(f['para_visita'])} — {nomes}")
    linhas += _registros(f["registros_de_visita"])
    if f["visitas_previstas"]:
        previstas = _com_tipos(f, len(f["visitas_previstas"]), [n["tipo"] for n in f["visitas_previstas"]])
        linhas.append(f"Visitas previstas nas próximas ações: {previstas}")
    vazio = f"Nada registrado sobre visitas {periodo.quando(f['frequencia'])}"
    return bloco("🏠 **Visitas (o que foi registrado)**", [f"- {l}" for l in linhas] or [f"- {vazio}"])


def _registros(registros: list[tuple[dict[str, Any], str]]) -> list[str]:
    linhas = [f"{_negocio(negocio)}: {trecho(texto)}" for negocio, texto in registros[:3]]
    if len(registros) > 3:
        linhas.append(f"e mais {len(registros) - 3} registro(s)")
    return linhas


def _propostas(f: dict[str, Any]) -> str:
    if not (f["palavras"]["proposta"] or f["palavras"]["negociacao"]):
        return ""
    linhas = []
    if f["para_proposta"]:
        linhas.append(f"Entraram em negociação: {_com_tipos(f, len(f['para_proposta']), [n['tipo'] for n in f['para_proposta']])}")
    linhas += _registros(f["registros_de_proposta"])
    vazio = f"Nada registrado sobre propostas {periodo.quando(f['frequencia'])}"
    return bloco("📄 **Propostas e negociações**", [f"- {l}" for l in linhas] or [f"- {vazio}"])


def _fechamentos(f: dict[str, Any]) -> str:
    linhas = []
    for n in f["ganhos"]:
        valor = textos.reais(n["centavos"]) if n["centavos"] else "valor não registrado"
        linhas.append(f"✅ {n['titulo']} — {_negocio(n)}{_do_tipo(f, n)}: {valor}")
    total = sum(int(n["centavos"] or 0) for n in f["ganhos"])
    if total:
        linhas.append(f"Total fechado {periodo.quando(f['frequencia'])}: {textos.reais(total)}")
    for n, motivo in f["perdidos"]:
        linhas.append(f"❌ {n['titulo']} — {_negocio(n)}{_do_tipo(f, n)}: {_motivo(motivo)}")
    cabeca = f"🏁 **Fechamentos: {len(f['ganhos'])} · Perdas: {len(f['perdidos'])}**"
    vazio = f"Nenhum fechamento nem perda {periodo.quando(f['frequencia'])}"
    return bloco(cabeca, lista(linhas, maximo=8) if linhas else [f"- {vazio}"])


def _do_tipo(f: dict[str, Any], n: dict[str, Any]) -> str:
    """ ", <grupo>" no fechamento, só quando a instalação tem grupos de negócio (sem grupos, o resumo não fala de tipo)."""
    return f", {n['tipo'].lower()}" if f["grupos"] else ""


def _motivo(motivo: str | None) -> str:
    if not motivo:
        return "motivo não registrado"
    return f"último registro: «{trecho(motivo, 100)}»"


def _tarefas(f: dict[str, Any]) -> str:
    q = periodo.quando(f["frequencia"])
    linhas = [f"Concluídas {q}: {len(f['concluidas'])}"] if f["concluidas"] else []
    if f["atrasadas"]:
        linhas.append(f"Atrasadas: {len(f['atrasadas'])} — " + ", ".join(t["titulo"] for t in f["atrasadas"][:3]))
    if f["esperando_aprovacao"]:
        linhas.append(f"Propostas do Als Copilot esperando sua aprovação: {len(f['esperando_aprovacao'])}")
        linhas += [f"  «{t['titulo']}», desde {textos.dia(t['criado_em'])}" for t in f["esperando_aprovacao"][:4]]
    if not linhas:
        return ""
    return bloco("📋 **Tarefas**", [l if l.startswith("  ") else f"- {l}" for l in linhas])


def _amanha(f: dict[str, Any]) -> str:
    freq = f["frequencia"]
    linhas = []
    for nome, quantos in textos.por_responsavel(f["de_amanha"]).most_common():
        dele = [n for n in f["de_amanha"] if quem(n.get("responsavel")) == nome]
        linhas.append(f"{nome}: {quantos} — " + "; ".join(trecho(n["proxima_acao_texto"] or n["titulo"], 80) for n in dele[:2]))
    for e in f["agenda_de_amanha"][:3]:
        linhas.append(f"{textos.hora(e['inicio_em'])} {e['titulo']} ({quem(e['responsavel'])})")
    vazio = f"Nenhuma próxima ação nem compromisso marcado {periodo.para_frente(freq)}"
    return bloco(f"📅 **{periodo.cabeca_da_frente(freq)}**", lista(linhas) or [f"- {vazio}"])


def _funil(f: dict[str, Any]) -> str:
    abertos = f["abertos"]
    total = "o total, não só o de hoje" if f["frequencia"] == "diaria" else "o total, não só o do período"
    linhas = [f"Abertos: {_com_tipos(f, len(abertos), [n['tipo'] for n in abertos])}"]
    por_fase = Counter(n["fase"] or "sem fase" for n in abertos)
    conhecidas = [fase["nome"] for fase in f["fases"]]
    ordem = conhecidas + sorted(set(por_fase) - set(conhecidas))
    linhas += [f"{fase}: {por_fase[fase]}" for fase in ordem if por_fase.get(fase)]
    return bloco(f"📊 **O funil agora** ({total})", [f"- {l}" for l in linhas])


def _gargalos(f: dict[str, Any]) -> str:
    linhas = []
    if f["vencidas"]:
        por_quem = textos.por_responsavel(f["vencidas"]).most_common(4)
        linhas.append(f"Próximas ações vencidas: {len(f['vencidas'])} — {textos.vezes(dict(por_quem))}")
    if f["negociacao_parada"]:
        parada = _com_tipos(f, len(f["negociacao_parada"]), [n["tipo"] for n in f["negociacao_parada"]])
        linhas.append(f"Em negociação sem contato há {constantes.DIAS_SEM_CONTATO}+ dias: {parada}")
    if f["esperando"]:
        linhas.append(_esperando(f))
    if f["sem_proxima"]:
        linhas.append(f"Abertos sem próxima ação: {len(f['sem_proxima'])}")
    if f["sem_responsavel"]:
        linhas.append(f"Abertos sem responsável: {len(f['sem_responsavel'])}")
    return bloco("🚦 **Gargalos**", [f"- {l}" for l in linhas]) if linhas else ""


def _esperando(f: dict[str, Any]) -> str:
    mais_antiga = f["esperando"][0]
    horas = int((f["agora"] - mais_antiga["ultima_mensagem_em"]).total_seconds() // 3600)
    return (
        f"Clientes esperando resposta (de 1 h a 3 dias): {len(f['esperando'])} "
        f"(o mais antigo, {mais_antiga['contato'] or 'sem nome'}, há {horas} h)"
    )
