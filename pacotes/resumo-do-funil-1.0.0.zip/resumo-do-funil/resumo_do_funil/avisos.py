"""
O AVISO À ALS QUANDO QUEBRA (story 42.1) — vai a QUEM CONSERTA (`contexto.avisar(..., para="als")`), não ao dono:
"a consulta ao banco falhou" ele não tem como resolver.

UM AVISO POR PROBLEMA, NÃO UM POR RODADA: o que já foi avisado fica no estado e não se repete; quando passa, sai um
"voltou ao normal". Aviso que não saiu NÃO é marcado como avisado — a rodada seguinte tenta de novo.
"""

from __future__ import annotations

TITULO = "Resumo do funil"

PROBLEMAS = {
    "leitura": "a leitura do banco falhou (uma tabela ou coluna do sistema pode ter mudado de versão)",
    "aviso": "o aviso ao dono não saiu (nenhum canal aceitou)",
}


async def tratar(contexto, problemas: dict[str, str], *, rodada_completa: bool) -> None:
    estado = await contexto.estado.ler()
    avisados: dict[str, str] = dict(estado.get("avisados") or {})
    mudou = await _avisar_novos(contexto, problemas, avisados)
    if rodada_completa:
        mudou = await _avisar_voltou(contexto, problemas, avisados) or mudou
    if mudou:
        estado = await contexto.estado.ler()
        estado["avisados"] = avisados
        await contexto.estado.gravar(estado)


async def _avisar_novos(contexto, problemas: dict[str, str], avisados: dict[str, str]) -> bool:
    mudou = False
    for codigo, detalhe in problemas.items():
        if codigo in avisados:
            continue
        texto = (
            f"A automação do resumo do funil precisa de atenção: {PROBLEMAS.get(codigo, codigo)}.\nDetalhe: {detalhe}\n"
            "Enquanto isso, o dono não recebe o resumo do período."
        )
        try:
            await contexto.avisar(texto, para="als", titulo=TITULO)
        except Exception as erro:  # noqa: BLE001
            contexto.registrar(f"o aviso à ALS não saiu ({erro}); tento de novo na próxima rodada")
            continue
        avisados[codigo] = detalhe
        mudou = True
    return mudou


async def _avisar_voltou(contexto, problemas: dict[str, str], avisados: dict[str, str]) -> bool:
    mudou = False
    for codigo in [c for c in avisados if c not in problemas]:
        try:
            await contexto.avisar(
                f"Voltou ao normal: o resumo do funil — {PROBLEMAS.get(codigo, codigo)} — funcionou de novo.",
                para="als",
                titulo=TITULO,
            )
        except Exception as erro:  # noqa: BLE001
            contexto.registrar(f"o aviso de 'voltou ao normal' não saiu ({erro})")
            continue
        del avisados[codigo]
        mudou = True
    return mudou
