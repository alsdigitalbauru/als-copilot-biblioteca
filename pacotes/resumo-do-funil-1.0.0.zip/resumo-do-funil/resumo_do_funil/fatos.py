"""
OS FATOS DO PERÍODO (story 42.1) — os números, contados uma vez a partir do que a `leitura.py` trouxe. Sem banco e sem IA.

Só conta o que foi REGISTRADO: o que não foi registrado não aparece como se tivesse acontecido.
R$ só de negócio GANHO no período (a conta do painel); negócio aberto nunca tem valor no texto.
"""

from __future__ import annotations

import re
from collections import Counter
from datetime import datetime, timedelta
from typing import Any

from . import constantes, periodo, quer, tipo, textos

_PELA_RESPOSTA = re.compile(r"^\s*Pela resposta de ([^:]+):", re.IGNORECASE)
ESPERA_MINIMA = timedelta(hours=constantes.ESPERA_MINIMA_HORAS)
ESPERA_MAXIMA = timedelta(days=constantes.ESPERA_MAXIMA_DIAS)


def fatos(dados: dict[str, Any], campos: dict[str, Any], agora: datetime) -> dict[str, Any]:
    """Tudo o que o texto, as sugestões e o bloco do cliente usam, contado uma vez."""
    freq = periodo.frequencia(campos)
    inicio = periodo.inicio_do_periodo(agora, freq)
    pals = _palavras(campos)
    grupos = tipo.grupos(textos.campo(campos, "tipos_de_negocio", constantes.TIPOS_DE_NEGOCIO))
    negocios = _negocios(dados["negocios"], grupos)
    abertos = [n for n in negocios.values() if n["situacao"] == "aberta"]
    historico = _historico(dados["historico"], negocios, pals)
    return {
        "agora": agora,
        "frequencia": freq,
        "titulo": periodo.titulo(agora, freq),
        "grupos": grupos,
        "palavras": pals,
        "negocios": negocios,
        "abertos": abertos,
        "fases": dados["fases"],
        "leads": dados["leads"],
        "tipos_dos_leads": [_tipo_de(negocios, lead["negocio"]) for lead in dados["leads"]],
        "negocios_novos": [n for n in negocios.values() if _dentro(n["criada_em"], inicio, agora)],
        "ninguem": [o for o in dados["ninguem_assumiu"] if not o["tem_responsavel"]],
        "passagens": dados["passagens"],
        "movimento": quer.quem_entra(dados, negocios, inicio, agora),
        "por_lead": quer.por_lead(negocios),
        **historico,
        **_conversas(dados["conversas"], inicio, agora),
        **_tarefas(dados["tarefas"], agora),
        **_prazos(dados, abertos, pals, periodo.inicio_de_amanha(agora),
                  periodo.fim_da_frente(agora, freq), agora),
        **_fechamentos(negocios, inicio, agora, historico["ultimo"]),
    }


def houve_movimento(f: dict[str, Any]) -> bool:
    chaves = ("leads", "mudancas", "registros_de_visita", "registros_de_proposta", "respostas",
              "passagens", "novas", "ganhos", "perdidos", "concluidas", "movimento")
    return any(f[chave] for chave in chaves) or bool(f["do_cliente_hoje"])


def _palavras(campos: dict[str, Any]) -> dict[str, list[str]]:
    return {
        "visita": textos.palavras(textos.campo(campos, "palavras_de_visita", constantes.PALAVRAS_DE_VISITA)),
        "proposta": textos.palavras(textos.campo(campos, "palavras_de_proposta", constantes.PALAVRAS_DE_PROPOSTA)),
        "negociacao": textos.palavras(textos.campo(campos, "palavras_de_negociacao", constantes.PALAVRAS_DE_NEGOCIACAO)),
    }


def _dentro(instante: datetime | None, inicio: datetime, fim: datetime) -> bool:
    return instante is not None and inicio <= instante < fim


def _tipo_de(negocios: dict[str, dict[str, Any]], negocio_id: Any) -> str:
    return negocios[negocio_id]["tipo"] if negocio_id in negocios else tipo.SEM_TIPO


def _negocios(lista: list[dict[str, Any]], grupos: list[tuple[str, list[str]]]) -> dict[str, dict[str, Any]]:
    return {n["id"]: {**n, "tipo": tipo.do_negocio(n, grupos)} for n in lista}


def _destino_da_fase(texto: Any) -> str | None:
    """ "Com a equipe → Visita Agendada" → "Visita Agendada". Outro texto ("Negociação aberta: …") não é mudança."""
    partes = str(texto or "").split(" → ", 1)
    if len(partes) != 2:
        return None
    return partes[1].strip() or None


def _historico(historico: list[dict[str, Any]], negocios: dict[str, dict[str, Any]],
               pals: dict[str, list[str]]) -> dict[str, Any]:
    return {**_mudancas(historico, negocios, pals), **_registros(historico, negocios, pals)}


def _mudancas(historico: list[dict[str, Any]], negocios: dict[str, dict[str, Any]],
              pals: dict[str, list[str]]) -> dict[str, Any]:
    mudancas: list[tuple[str, str]] = []
    visita: list[dict[str, Any]] = []
    proposta: list[dict[str, Any]] = []
    for h in historico:
        destino = _destino_da_fase(h["texto"]) if h["tipo"] == "fase" else None
        if not destino:
            continue
        negocio = negocios.get(h["negocio"])
        mudancas.append((destino, _tipo_de(negocios, h["negocio"])))
        if negocio and textos.tem(destino, pals["visita"]):
            visita.append(negocio)
        elif negocio and textos.tem(destino, pals["negociacao"]):
            proposta.append(negocio)
    return {"mudancas": mudancas, "para_visita": visita, "para_proposta": proposta}


def _registros(historico: list[dict[str, Any]], negocios: dict[str, dict[str, Any]],
               pals: dict[str, list[str]]) -> dict[str, Any]:
    visita: dict[str, str] = {}
    proposta: dict[str, str] = {}
    respostas: Counter[str] = Counter()
    ultimo: dict[str, str] = {}
    for h in historico:
        texto = str(h["texto"] or "")
        if h["tipo"] == "mensagem":
            achou = _PELA_RESPOSTA.match(texto)
            if achou:
                respostas[achou.group(1).strip()] += 1
            ultimo[h["negocio"]] = texto
        if h["tipo"] in ("mensagem", "agenda") and h["negocio"] in negocios:
            if textos.tem(texto, pals["visita"]):
                visita[h["negocio"]] = texto
            elif textos.tem(texto, pals["proposta"]):
                proposta[h["negocio"]] = texto
    return {
        "registros_de_visita": [(negocios[k], v) for k, v in visita.items()],
        "registros_de_proposta": [(negocios[k], v) for k, v in proposta.items()],
        "respostas": respostas,
        "ultimo": ultimo,
    }


def _conversas(conversas: list[dict[str, Any]], inicio: datetime, agora: datetime) -> dict[str, Any]:
    esperando = sorted((c for c in conversas if _esperando(c, agora)), key=lambda c: c["ultima_mensagem_em"])
    return {
        "novas": [c for c in conversas if _dentro(c["criada_em"], inicio, agora)],
        "esperando": esperando,
        "do_cliente_hoje": sum(int(c["do_cliente_hoje"] or 0) for c in conversas),
        "conversas_com_cliente_hoje": sum(1 for c in conversas if c["do_cliente_hoje"]),
        "da_equipe_hoje": sum(int(c["da_equipe_hoje"] or 0) for c in conversas),
    }


def _esperando(conversa: dict[str, Any], agora: datetime) -> bool:
    if conversa["ultima_mensagem_de"] != "cliente" or conversa["situacao"] == "encerrada":
        return False
    if conversa["ultima_mensagem_em"] is None:
        return False
    return ESPERA_MINIMA <= agora - conversa["ultima_mensagem_em"] <= ESPERA_MAXIMA


def _tarefas(tarefas: list[dict[str, Any]], agora: datetime) -> dict[str, Any]:
    em_aberto = [t for t in tarefas if t["status"] not in constantes.FINAIS]
    return {
        "concluidas": [t for t in tarefas if t["status"] == "concluida"],
        "atrasadas": [t for t in em_aberto if t["prazo_em"] is not None and t["prazo_em"] < agora],
        "esperando_aprovacao": sorted(
            (t for t in em_aberto if t["status"] in constantes.ESPERANDO_APROVACAO), key=lambda t: t["criado_em"]
        ),
    }


def _prazos(dados: dict[str, Any], abertos: list[dict[str, Any]], pals: dict[str, list[str]],
            amanha: datetime, frente: datetime, agora: datetime) -> dict[str, Any]:
    de_amanha = sorted(
        (n for n in abertos if _dentro(n["proxima_acao_quando"], amanha, frente)),
        key=lambda n: n["proxima_acao_quando"],
    )
    agenda = [e for e in dados["agenda"] if _dentro(e["inicio_em"], amanha, frente)]
    visita = pals["visita"]
    return {
        "de_amanha": de_amanha,
        "agenda_de_amanha": agenda,
        "visitas_de_amanha": [n for n in de_amanha if textos.tem(n["proxima_acao_texto"], visita)]
        + [e for e in agenda if textos.tem(e["titulo"], visita)],
        "visitas_previstas": [
            n for n in abertos
            if n["proxima_acao_quando"] and n["proxima_acao_quando"] >= agora
            and textos.tem(n["proxima_acao_texto"], visita)
        ],
        "vencidas": [n for n in abertos if n["proxima_acao_quando"] is not None and n["proxima_acao_quando"] < agora],
        "sem_proxima": [n for n in abertos if n["proxima_acao_quando"] is None],
        "sem_responsavel": [n for n in abertos if not n["responsavel"]],
        "negociacao_parada": _parada(abertos, pals["negociacao"], agora),
    }


def _parada(abertos: list[dict[str, Any]], negociacao: list[str], agora: datetime) -> list[dict[str, Any]]:
    limite = agora - timedelta(days=constantes.DIAS_SEM_CONTATO)
    return [
        n for n in abertos
        if textos.tem(n["fase"], negociacao) and (n["ultimo_contato_em"] is None or n["ultimo_contato_em"] < limite)
    ]


def _fechamentos(negocios: dict[str, dict[str, Any]], inicio: datetime, agora: datetime,
                 ultimo: dict[str, str]) -> dict[str, Any]:
    ganhos = [n for n in negocios.values() if n["situacao"] == "ganha" and _dentro(n["fechada_em"], inicio, agora)]
    perdidos = [n for n in negocios.values() if n["situacao"] == "perdida" and _dentro(n["fechada_em"], inicio, agora)]
    return {"ganhos": ganhos, "perdidos": [(n, ultimo.get(n["id"])) for n in perdidos]}
