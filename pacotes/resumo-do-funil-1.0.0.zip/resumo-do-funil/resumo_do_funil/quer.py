"""
O QUE CADA CLIENTE QUER (story 42.1) — uma linha por cliente com o que ele procura, SÓ com o que já está registrado no
sistema. Sem IA, sem rota e sem coluna nova: lê o que a leitura trouxe. O que falta vira "não informado".
Quem entra, a ordem e o bloco ficam aqui; cada atributo da linha sai de `atributos.py`.

Ordem: primeiro os que têm urgência, depois os de movimento mais recente; os sem nada registrado por último.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from . import atributos, constantes, textos

MAXIMO_DE_DESEJOS = 3


def maximo(campos: dict[str, Any]) -> int:
    try:
        valor = int(campos.get("maximo_de_clientes", constantes.MAXIMO_DE_CLIENTES))
    except (TypeError, ValueError):
        valor = constantes.MAXIMO_DE_CLIENTES
    return min(max(valor, 1), constantes.TETO_DE_CLIENTES)


def apontados(texto: Any) -> list[tuple[str, str]]:
    """ "Rótulo=Caminho.Na.Ficha" por linha → [("Rótulo", "Caminho.Na.Ficha")]. Linha sem "=" não vale."""
    saida = []
    for linha in str(texto or "").splitlines():
        rotulo, sinal, caminho = linha.partition("=")
        if sinal and rotulo.strip() and caminho.strip():
            saida.append((rotulo.strip(), caminho.strip()))
    return saida


def quem_entra(dados: dict[str, Any], negocios: dict[str, dict[str, Any]],
               inicio: datetime, agora: datetime) -> dict[str, datetime]:
    """Cada cliente (lead) com movimento no período, e o instante do movimento mais recente."""
    movimento: dict[str, datetime] = {}
    for lead in dados["leads"]:
        _marcar(movimento, lead["id"], lead["criado_em"])
    for negocio in negocios.values():
        _marcar(movimento, negocio.get("lead_id"), _maior([negocio["criada_em"], negocio["fechada_em"]], inicio, agora))
    for h in dados["historico"]:
        negocio = negocios.get(h["negocio"])
        if negocio:
            _marcar(movimento, negocio.get("lead_id"), h["quando"])
    for c in dados["conversas"]:
        if c["do_cliente_hoje"]:
            _marcar(movimento, c.get("lead_id"), c["ultima_mensagem_em"] or agora)
    for p in dados["passagens"]:
        _marcar(movimento, p.get("lead_id"), p["quando"])
    return movimento


def por_lead(negocios: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """O negócio que representa o cliente: o aberto, e o mais novo."""
    escolhido: dict[str, dict[str, Any]] = {}
    for negocio in negocios.values():
        lead = negocio.get("lead_id")
        if lead and (lead not in escolhido or _chave(negocio) > _chave(escolhido[lead])):
            escolhido[lead] = negocio
    return escolhido


def candidatos(f: dict[str, Any]) -> list[str]:
    """Os clientes de movimento mais recente: só eles são lidos no detalhe (o resto aparece com o que já veio)."""
    mais_recentes = sorted(f["movimento"].items(), key=lambda par: par[1], reverse=True)
    return [lead for lead, _ in mais_recentes[: constantes.CANDIDATOS]]


def sem_detalhe() -> dict[str, list[dict[str, Any]]]:
    return {"perfis": [], "passagens": [], "itens": []}


def clientes(f: dict[str, Any], detalhes: dict[str, list[dict[str, Any]]],
             campos: dict[str, Any]) -> list[dict[str, Any]]:
    """Cada cliente que entrou, com a linha pronta e as marcas de urgência e de "nada registrado", na ordem do bloco."""
    idx = _indice(detalhes)
    nomes = _nomes(f)
    lidos = set(candidatos(f))  # só estes tiveram o detalhe lido; os outros não são dados como "nada registrado"
    regras = {
        "urgencia": textos.pares(textos.campo(campos, "palavras_de_urgencia", constantes.PALAVRAS_DE_URGENCIA)),
        "item": apontados(textos.campo(campos, "campos_do_item", constantes.CAMPOS_DO_ITEM)),
    }
    prontos = [
        _cliente(lead, instante, f, idx, nomes, regras, lido=lead in lidos)
        for lead, instante in f["movimento"].items()
    ]
    return sorted(prontos, key=lambda c: (c["nada"], not c["urgente"], -c["movimento_em"].timestamp()))


def bloco(f: dict[str, Any], maximo_de_linhas: int) -> str:
    """O bloco "o que cada cliente quer": até `maximo_de_linhas`; o resto vira "e mais N"."""
    if f.get("quer_falhou"):
        return textos.bloco(
            "👥 **O que cada cliente quer**",
            ["- não consegui ler o que cada cliente quer agora; o resto do resumo saiu"],
        )
    lista = f.get("clientes") or []
    if not lista:
        return ""
    linhas = [f"- {c['linha']}" for c in lista[:maximo_de_linhas]]
    resto = lista[maximo_de_linhas:]
    if resto:
        sem = sum(1 for c in resto if c["nada"])
        extra = f" ({sem} sem nada registrado sobre o que procuram)" if sem else ""
        linhas.append(f"- e mais {len(resto)}{extra}")
    return textos.bloco(f"👥 **O que cada cliente quer: {len(lista)}**", linhas)


def _chave(negocio: dict[str, Any]) -> tuple[bool, datetime]:
    return (negocio["situacao"] == "aberta", negocio["criada_em"])


def _marcar(movimento: dict[str, datetime], lead_id: Any, instante: datetime | None) -> None:
    if not lead_id or instante is None:
        return
    if lead_id not in movimento or instante > movimento[lead_id]:
        movimento[lead_id] = instante


def _maior(instantes: list[datetime | None], inicio: datetime, agora: datetime) -> datetime | None:
    dentro = [i for i in instantes if i is not None and inicio <= i < agora]
    return max(dentro) if dentro else None


def _indice(detalhes: dict[str, list[dict[str, Any]]]) -> dict[str, Any]:
    itens: dict[str, list[dict[str, Any]]] = {}
    for item in detalhes["itens"]:
        itens.setdefault(item["negocio"], []).append(item)
    return {
        "perfis": {p["lead_id"]: p for p in detalhes["perfis"]},
        "passagens": {p["lead_id"]: p for p in detalhes["passagens"]},
        "itens": itens,
    }


def _nomes(f: dict[str, Any]) -> dict[str, str]:
    nomes = {n["lead_id"]: n["contato"] for n in f["negocios"].values() if n.get("lead_id") and n.get("contato")}
    nomes.update({lead["id"]: lead["nome"] for lead in f["leads"] if lead.get("nome")})
    return nomes


def _cliente(lead: str, instante: datetime, f: dict[str, Any], idx: dict[str, Any],
             nomes: dict[str, str], regras: dict[str, Any], lido: bool) -> dict[str, Any]:
    negocio = f["por_lead"].get(lead)
    perfil = idx["perfis"].get(lead) or {}
    passagem = idx["passagens"].get(lead) or {}
    itens = idx["itens"].get(negocio["id"], []) if negocio else []
    livres = _livres(negocio, perfil, passagem)
    campos_da_linha = atributos.atributos(negocio, livres, perfil, itens, regras)
    responsavel = textos.quem(negocio.get("responsavel")) if negocio else "sem negócio"
    nome = nomes.get(lead) or "sem nome"
    if not lido:
        linha, nada = _linha_sem_detalhe(nome, responsavel, campos_da_linha), False
    else:
        linha, nada = _linha(nome, responsavel, campos_da_linha), not any(t for _, t in campos_da_linha)
    return {
        "linha": linha,
        "nada": nada,
        "urgente": any(texto for nome_do_campo, texto in campos_da_linha if nome_do_campo == "urgência"),
        "movimento_em": instante,
    }


def _livres(negocio: dict[str, Any] | None, perfil: dict[str, Any], passagem: dict[str, Any]) -> dict[str, Any]:
    """Os textos que o cliente escreveu ou que o sistema registrou, já sem contato (e sem o "Pedido:" da passagem)."""
    desejos = [textos.sem_contato(_texto_do_desejo(d)) for d in (perfil.get("desejos") or [])]
    return {
        "intencao": textos.sem_contato((negocio or {}).get("intencao")),
        "desejos": [d for d in desejos if d][:MAXIMO_DE_DESEJOS],
        "resumo": textos.sem_contato(textos.sem_pedido(passagem.get("resumo"))),
        "proxima": textos.sem_contato((negocio or {}).get("proxima_acao_texto")),
    }


def _texto_do_desejo(desejo: Any) -> str:
    if isinstance(desejo, dict):
        return str(desejo.get("texto") or "")
    return str(desejo or "")


def _linha(nome: str, responsavel: str, campos_da_linha: list[tuple[str, str]]) -> str:
    cabeca = f"{nome} ({responsavel})"
    achados = [f"{rotulo}: {texto}" for rotulo, texto in campos_da_linha if texto]
    if not achados:
        return f"{cabeca}: nada registrado sobre o que procura"
    faltam = [rotulo for rotulo, texto in campos_da_linha if not texto]
    fim = f". Não informado: {', '.join(faltam)}" if faltam else ""
    return f"{cabeca}: " + " · ".join(achados) + fim


def _linha_sem_detalhe(nome: str, responsavel: str, campos_da_linha: list[tuple[str, str]]) -> str:
    """Cliente fora dos de movimento mais recente: o que já veio do negócio, sem afirmar o que não foi lido."""
    cabeca = f"{nome} ({responsavel})"
    achados = [f"{rotulo}: {texto}" for rotulo, texto in campos_da_linha if texto]
    aviso = "detalhe não lido (fora dos clientes de movimento mais recente)"
    if not achados:
        return f"{cabeca}: {aviso}"
    return f"{cabeca}: " + " · ".join(achados) + f". {aviso}"
