"""
O RELÓGIO DA RODADA (story 42.1) — num arquivo só, para o teste poder trocá-lo (`relogio.agora = …`).

"Hoje" é o dia de São Paulo, de 00:00 até a hora da rodada.
"""

from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo

FUSO = ZoneInfo("America/Sao_Paulo")


def agora() -> datetime:
    return datetime.now(FUSO)
