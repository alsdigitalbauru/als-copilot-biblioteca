"""
AS SUGESTÕES DA IA (story 42.1) — o ÚNICO arquivo do pacote que chama a IA, e só quando há o que analisar.

O pedido do dono que justifica a única chamada: sugestões para fechar mais negócios. É análise do dia, não contagem.
Então:

    período sem movimento     nenhuma chamada (o resumo sai com as sugestões fixas)
    período com movimento     UMA chamada, com o resumo já pronto (sem o bloco "o que cada cliente quer") → até 3 sugestões
    a IA falhou ou calou      as sugestões fixas (`fixas.sugestoes_fixas`), sem esperar nada
"""

from __future__ import annotations

from . import constantes

_PERGUNTA = (
    "Você ajuda o dono de uma empresa. Abaixo está o resumo do que foi registrado no funil dela. Sugira até {maximo} "
    "melhorias concretas para o próximo período, buscando {objetivo}. Regras: português do Brasil; uma sugestão por "
    "linha, cada linha começando com \"- \"; cada sugestão cita o número do resumo que a sustenta e, quando houver, o "
    "responsável; sem saudação, sem título, sem markdown além do \"- \"; não invente números, nomes nem fatos que não "
    "estão no resumo; não sugira mandar mensagem automática a clientes; se os dados não sustentam uma sugestão, não a "
    "escreva.\n\n{resumo}"
)


def _limpar(resposta: str) -> list[str]:
    linhas = []
    for linha in str(resposta or "").splitlines():
        linha = " ".join(linha.replace("*", "").split())
        if not linha.startswith("- "):
            continue
        linhas.append(linha[2:].strip())
        if len(linhas) == constantes.MAXIMO_DE_SUGESTOES:
            break
    return _caber(linhas)


def _caber(linhas: list[str]) -> list[str]:
    """O teto do bloco: as sugestões que cabem inteiras."""
    saida, total = [], 0
    for linha in linhas:
        total += len(linha) + 3
        if total > constantes.MAXIMO_DAS_SUGESTOES:
            break
        saida.append(linha)
    return saida


async def da_ia(contexto, resumo: str, objetivo: str) -> list[str]:
    """As sugestões da IA, ou [] (a rodada usa as fixas)."""
    pergunta = _PERGUNTA.format(maximo=constantes.MAXIMO_DE_SUGESTOES, objetivo=objetivo, resumo=resumo)
    try:
        sugestoes = _limpar(await contexto.ia(pergunta, segundos=constantes.SEGUNDOS_DA_IA))
    except Exception as erro:  # noqa: BLE001 — sem a IA, vão as sugestões fixas
        contexto.registrar(f"as sugestões da IA não vieram ({erro}); vão as fixas")
        return []
    if not sugestoes:
        contexto.registrar("a IA não devolveu sugestão no formato; vão as fixas")
    return sugestoes
