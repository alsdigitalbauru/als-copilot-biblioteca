"""
OS NÚMEROS DO RESUMO DO FUNIL (story 42.1). Não importa ninguém — os outros arquivos do pacote leem daqui.
"""

#: O teto do texto de um aviso ao dono (`contexto.avisar` aceita até 4.000 caracteres), com folga.
MAXIMO_DO_TEXTO = 3900
#: O bloco "o que cada cliente quer" tem teto próprio: se a mensagem passa do teto, ele é o primeiro a encolher.
MAXIMO_DO_QUE_QUER = 1300
#: Quantas linhas uma lista de um bloco mostra antes do "e mais N".
LINHAS_POR_BLOCO = 5
#: O tamanho de um trecho de registro citado (o texto do histórico é livre).
TRECHO = 140
#: O tamanho do trecho do que o cliente quer, e o da frase da ficha resumida do item ligado.
TRECHO_DO_QUER = 110
TRECHO_DO_ITEM = 100

#: O que cada cliente quer: quantos entram no SQL de detalhe (os de movimento mais recente), e quantos aparecem por
#: padrão (campo `maximo_de_clientes`, de 1 a 30).
CANDIDATOS = 60
MAXIMO_DE_CLIENTES = 8
TETO_DE_CLIENTES = 30

#: Quantas linhas cada leitura pode trazer no período. Passou disso, a rodada vira erro em português (não resumo pela metade).
LINHAS_DO_PERIODO = 20000

#: As sugestões da IA (`sugestoes.py`): quantas, o tamanho delas e quanto se espera (sem elas, vão as fixas).
MAXIMO_DE_SUGESTOES = 3
MAXIMO_DAS_SUGESTOES = 700
SEGUNDOS_DA_IA = 60

#: A situação da tarefa (`src/tipos/tarefa.ts`): a que espera o dono aprovar e as finais.
ESPERANDO_APROVACAO = ("aguardando_aprovacao", "proposta_pronta")
FINAIS = ("concluida", "cancelada")

#: Negócio em negociação sem contato há tantos dias vira sugestão fixa. Conversa que espera resposta conta entre
#: tantas horas e tantos dias (antes disso o agente ainda responde; depois, é abandono).
DIAS_SEM_CONTATO = 3
ESPERA_MINIMA_HORAS = 1
ESPERA_MAXIMA_DIAS = 3

#: Os padrões dos campos (o `automacao.yaml` tem os mesmos; o teste confere). Vazio = desliga o bloco ou não separa.
TIPOS_DE_NEGOCIO = ""
PALAVRAS_DE_VISITA = "visita"
PALAVRAS_DE_PROPOSTA = "proposta\ncontraproposta"
PALAVRAS_DE_NEGOCIACAO = "negocia\nproposta"
PALAVRAS_DE_URGENCIA = "urgente\nurgência\no quanto antes\nimediat\nesta semana\nesse mês\nprecisa logo\nprazo"
CAMPOS_DO_ITEM = ""
OBJETIVO_DAS_SUGESTOES = "fechar mais negócios"
FREQUENCIA = "diaria"
DIA_DA_SEMANA = "sexta"
DIA_DO_MES = 31

#: O número do `automacao.yaml` — o teste o confere contra o arquivo.
PRAZO_DA_RODADA = 300
