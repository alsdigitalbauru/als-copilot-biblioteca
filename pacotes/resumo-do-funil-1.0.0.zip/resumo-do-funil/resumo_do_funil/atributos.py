"""
OS ATRIBUTOS DO CLIENTE (story 42.1) — cada campo do bloco "o que cada cliente quer", tirado da PRIMEIRA fonte que tiver.
É o `quer.py` que monta a linha; aqui fica só a conta de cada atributo. Sem IA e sem banco.

    o que quer        o grupo de negócio; a frase: a intenção, senão os desejos, senão o resumo da passagem
    tipo              as categorias do item ligado
    região            o local do perfil, senão o campo do item que o dono apontou como bairro ou cidade
    faixa de valor    os R$ que o cliente citou (como foram escritos) e o preço do item ligado
    características   os desejos do perfil, e os campos do item que o dono apontou (ou o resumo do item)
    urgência          a palavra de urgência que bateu no que o cliente escreveu
"""

from __future__ import annotations

from typing import Any

from . import constantes, textos, tipo

REGIAO = ("bairro", "cidade", "regiao", "local", "endereco")
ROTULO_DO_ITEM = "item ligado"


def atributos(negocio: dict[str, Any] | None, livres: dict[str, Any], perfil: dict[str, Any],
              itens: list[dict[str, Any]], regras: dict[str, Any]) -> list[tuple[str, str]]:
    return [
        ("o que quer", _o_que_quer(negocio, livres)),
        ("tipo", _tipo_do_item(itens)),
        ("região", _regiao(perfil, itens, regras["item"])),
        ("faixa de valor", _faixa(livres, itens)),
        ("características", _caracteristicas(livres, itens, regras["item"])),
        ("urgência", _urgencia(livres, regras["urgencia"])),
    ]


def _o_que_quer(negocio: dict[str, Any] | None, livres: dict[str, Any]) -> str:
    grupo = (negocio or {}).get("tipo")
    partes = [grupo.lower()] if grupo and grupo != tipo.SEM_TIPO else []
    frase = _frase(livres)
    if frase:
        partes.append(frase)
    return " — ".join(partes)


def _frase(livres: dict[str, Any]) -> str:
    """A primeira fonte que tiver: a intenção do negócio, os desejos do perfil, o resumo da passagem."""
    fonte = livres["intencao"] or "; ".join(livres["desejos"]) or livres["resumo"]
    return textos.trecho(fonte, constantes.TRECHO_DO_QUER) if fonte else ""


def rotulo_do_item(itens: list[dict[str, Any]]) -> str:
    return ROTULO_DO_ITEM if len(itens) == 1 else f"{ROTULO_DO_ITEM} +{len(itens) - 1}"


def _tipo_do_item(itens: list[dict[str, Any]]) -> str:
    categorias = itens[0].get("categorias") if itens else None
    return f"{categorias} ({rotulo_do_item(itens)})" if categorias else ""


def no_caminho(ficha: Any, caminho: str) -> str | None:
    """ "Details.Bedrooms" → o valor na ficha (um nó com "#texto" vale o "#texto"); caminho que não existe, None."""
    no = ficha
    for parte in caminho.split("."):
        if not isinstance(no, dict) or parte not in no:
            return None
        no = no[parte]
    if isinstance(no, dict):
        no = no.get("#texto")
    if no is None or isinstance(no, (dict, list)):
        return None
    return str(no).strip() or None


def _do_item(itens: list[dict[str, Any]], apontados: list[tuple[str, str]]) -> list[tuple[str, str]]:
    """Os campos do primeiro item ligado que o dono apontou e que têm valor: [(rótulo, valor)]."""
    if not itens:
        return []
    saida = []
    for rotulo, caminho in apontados:
        valor = no_caminho(itens[0].get("ficha"), caminho)
        if valor:
            saida.append((rotulo, valor))
    return saida


def _e_regiao(rotulo: str) -> bool:
    alvo = textos.sem_acento(rotulo)
    return any(palavra in alvo for palavra in REGIAO)


def _regiao(perfil: dict[str, Any], itens: list[dict[str, Any]], apontados: list[tuple[str, str]]) -> str:
    if perfil.get("local"):
        return str(perfil["local"]).strip()
    for rotulo, valor in _do_item(itens, apontados):
        if _e_regiao(rotulo):
            return f"{valor} ({rotulo_do_item(itens)})"
    return ""


def _faixa(livres: dict[str, Any], itens: list[dict[str, Any]]) -> str:
    fontes = (livres["intencao"], *livres["desejos"], livres["resumo"])
    citados = [r for texto in fontes for r in textos.extrair_reais(texto)]
    partes = ["; ".join(citados[:3])] if citados else []
    if itens and itens[0].get("valor") is not None:
        centavos = round(float(itens[0]["valor"]) * 100)
        partes.append(f"{ROTULO_DO_ITEM}: {textos.reais(centavos)}")
    return "; ".join(partes)


def _caracteristicas(livres: dict[str, Any], itens: list[dict[str, Any]], apontados: list[tuple[str, str]]) -> str:
    # Se o "o que quer" já trouxe os desejos (sem intenção do negócio), eles não se repetem aqui.
    repetidos = not livres["intencao"] and bool(livres["desejos"])
    partes = [] if repetidos else list(livres["desejos"])
    if itens and apontados:
        partes += [
            f"{rotulo}: {valor} ({rotulo_do_item(itens)})"
            for rotulo, valor in _do_item(itens, apontados) if not _e_regiao(rotulo)
        ]
    elif itens and itens[0].get("resumo"):
        partes.append(f"{textos.trecho(itens[0]['resumo'], constantes.TRECHO_DO_ITEM)} ({rotulo_do_item(itens)})")
    return "; ".join(partes)


def _urgencia(livres: dict[str, Any], pares: list[tuple[str, str]]) -> str:
    for texto in (livres["intencao"], *livres["desejos"], livres["resumo"], livres["proxima"]):
        achou = _palavra_que_bateu(texto, pares)
        if achou:
            return f"citou «{achou}»"
    return ""


def _palavra_que_bateu(texto: str, pares: list[tuple[str, str]]) -> str:
    """A palavra de urgência que aparece no texto, como o dono a escreveu no campo. O texto é só busca: não entende
    negação (ex.: «sem prazo» também conta)."""
    alvo = textos.sem_acento(texto)
    return next((escrita for escrita, normal in pares if normal and normal in alvo), "")
