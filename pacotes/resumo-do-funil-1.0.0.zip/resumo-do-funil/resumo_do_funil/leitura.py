"""
A LEITURA (story 42.1) — TODO o SQL do pacote, e só SELECT (o teste confere): a automação nunca escreve no funil.

    o período   de `inicio` até a hora da rodada (hoje, os últimos 7 dias ou o mês corrente)
    a frente    o "amanhã" (o dia seguinte, ou os 7 dias seguintes)

Duas partes: a BASE (o que foi registrado no período e o funil de agora) e o DETALHE (o perfil, a passagem mais recente e
os itens ligados dos clientes que entram no bloco "o que cada cliente quer"; só roda com esse bloco ligado e só para os
clientes de movimento mais recente). Cada consulta devolve linhas cruas; quem conta é o `fatos.py`.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from . import constantes

#: Os negócios que o resumo precisa: os abertos (o funil de agora, os gargalos, a frente) e os que no período nasceram,
#: fecharam ou ganharam registro. As pistas do grupo (`tipo.py`) vêm junto, e o cliente (`lead_id`) para o bloco do cliente.
NEGOCIOS = """
SELECT o.id::text AS id, o.titulo, o.situacao, o.criada_em, o.fechada_em, o.ultimo_contato_em,
       o.proxima_acao_texto, o.proxima_acao_quando, o.contato_id::text AS lead_id, o.intencao_do_lead AS intencao,
       f.nome AS fase, f.ordem AS fase_ordem, f.etapa AS fase_etapa,
       l.nome AS contato,
       COALESCE(u.nome, (SELECT string_agg(u2.nome, ', ' ORDER BY u2.nome)
                           FROM responsaveis_do_lead r JOIN usuarios u2 ON u2.id = r.usuario_id
                          WHERE r.lead_id = o.contato_id)) AS responsavel,
       (SELECT p.destino_rotulo FROM passagens_do_atendimento p
         WHERE p.lead_id = o.contato_id ORDER BY p.quando DESC LIMIT 1) AS pista_equipe,
       concat_ws(' ', o.titulo, o.intencao_do_lead) AS pista_titulo,
       (SELECT string_agg(concat_ws(' ', pr.nome,
                 (SELECT string_agg(v.value, ' ')
                    FROM jsonb_each_text(CASE WHEN jsonb_typeof(pr.ficha) = 'object' THEN pr.ficha ELSE '{}'::jsonb END) v
                   WHERE length(v.value) <= 40)), ' ')
          FROM itens_da_oportunidade i JOIN produtos pr ON pr.id = i.produto_id
         WHERE i.oportunidade_id = o.id) AS pista_item,
       CASE WHEN o.situacao = 'ganha' THEN COALESCE((
         SELECT sum(round(p.valor * 100)) FROM itens_da_oportunidade i JOIN produtos p ON p.id = i.produto_id
          WHERE i.oportunidade_id = o.id), 0) ELSE 0 END::bigint AS centavos
  FROM oportunidades o
  LEFT JOIN fases_do_funil f ON f.id = o.fase_id
  LEFT JOIN leads l ON l.id = o.contato_id
  LEFT JOIN usuarios u ON u.id = o.responsavel_id
 WHERE o.situacao = 'aberta'
    OR o.fechada_em >= %s OR o.criada_em >= %s
    OR EXISTS (SELECT 1 FROM historico_da_oportunidade h WHERE h.oportunidade_id = o.id AND h.quando >= %s)
"""

FASES = "SELECT nome, ordem, etapa FROM fases_do_funil ORDER BY ordem"

LEADS = """
SELECT l.id::text AS id, l.nome, l.origem, l.criado_em,
       (SELECT o.id::text FROM oportunidades o WHERE o.contato_id = l.id ORDER BY o.criada_em DESC LIMIT 1) AS negocio
  FROM leads l
 WHERE l.criado_em >= %s AND l.criado_em < %s
 ORDER BY l.criado_em
"""

#: O LIMIT é o teto do período (mais uma linha, para o teste de tamanho dizer que passou).
HISTORICO = """
SELECT h.oportunidade_id::text AS negocio, h.tipo, h.texto, h.autor, h.quando
  FROM historico_da_oportunidade h
 WHERE h.quando >= %s AND h.quando < %s
 ORDER BY h.quando
 LIMIT %s
"""

#: As conversas do período e as que esperam resposta (a última mensagem é do cliente), com as mensagens do período contadas.
CONVERSAS = """
SELECT c.canal, c.criada_em, c.ultima_mensagem_de, c.ultima_mensagem_em, c.situacao, c.contato_id::text AS lead_id,
       l.nome AS contato,
       (SELECT count(*) FROM mensagens_do_atendimento m
         WHERE m.conversa_id = c.id AND m.de = 'cliente' AND m.quando >= %s AND m.quando < %s)::int AS do_cliente_hoje,
       (SELECT count(*) FROM mensagens_do_atendimento m
         WHERE m.conversa_id = c.id AND m.de = 'humano' AND m.quando >= %s AND m.quando < %s)::int AS da_equipe_hoje
  FROM conversas_de_atendimento c
  LEFT JOIN leads l ON l.id = c.contato_id
 WHERE c.criada_em >= %s OR c.ultima_mensagem_em >= %s
    OR (c.ultima_mensagem_de = 'cliente' AND c.situacao IS DISTINCT FROM 'encerrada')
"""

PASSAGENS = """
SELECT p.id::text AS id, p.lead_id::text AS lead_id, p.destino_rotulo, p.quando, l.nome AS contato,
       COALESCE(json_agg(json_build_object('nome', pp.nome, 'foi', pp.foi_falar_em IS NOT NULL) ORDER BY pp.nome)
                FILTER (WHERE pp.id IS NOT NULL), '[]'::json) AS pessoas
  FROM passagens_do_atendimento p
  LEFT JOIN leads l ON l.id = p.lead_id
  LEFT JOIN pessoas_da_passagem pp ON pp.passagem_id = p.id
 WHERE p.quando >= %s AND p.quando < %s
 GROUP BY p.id, l.nome
 ORDER BY p.quando
"""

#: A oferta que ninguém assumiu no período, e se o contato tem alguém AGORA (um responsável, ou um negócio aberto com dono).
NINGUEM_ASSUMIU = """
SELECT o.id::text AS id, o.encerrada_em, l.nome AS contato,
       (EXISTS (SELECT 1 FROM responsaveis_do_lead r WHERE r.lead_id = o.lead_id)
        OR EXISTS (SELECT 1 FROM oportunidades n
                    WHERE n.contato_id = o.lead_id AND n.situacao = 'aberta' AND n.responsavel_id IS NOT NULL))
         AS tem_responsavel
  FROM ofertas_de_atendimento o
  LEFT JOIN leads l ON l.id = o.lead_id
 WHERE o.estado = 'esgotada' AND o.encerrada_em >= %s AND o.encerrada_em < %s
"""

#: As tarefas em aberto (atrasadas, esperando aprovação) e as concluídas no período.
TAREFAS = """
SELECT t.id::text AS id, t.titulo, t.status, t.prazo_em, t.criado_em, t.atualizado_em, u.nome AS responsavel
  FROM tarefas t
  LEFT JOIN usuarios u ON u.id = t.responsavel_usuario_id
 WHERE t.status NOT IN ('concluida', 'cancelada')
    OR (t.status = 'concluida' AND t.atualizado_em >= %s AND t.atualizado_em < %s)
"""

#: A agenda do período e da frente. O responsável é o do negócio ligado; sem negócio, quem marcou.
AGENDA = """
SELECT e.titulo, e.inicio_em, e.situacao, l.nome AS contato, COALESCE(ur.nome, uc.nome) AS responsavel
  FROM eventos_agenda e
  LEFT JOIN leads l ON l.id = e.contato_id
  LEFT JOIN oportunidades o ON o.id = e.oportunidade_id
  LEFT JOIN usuarios ur ON ur.id = o.responsavel_id
  LEFT JOIN usuarios uc ON uc.id = e.criado_por_usuario_id
 WHERE e.inicio_em >= %s AND e.inicio_em < %s AND e.situacao IS DISTINCT FROM 'cancelado'
 ORDER BY e.inicio_em
"""

#: O DETALHE do bloco "o que cada cliente quer": só para os clientes que entram (`quer.candidatos`).
PERFIS = """
SELECT p.lead_id::text AS lead_id, p.local, p.desejos
  FROM perfis_dos_leads p
 WHERE p.lead_id = ANY(%s::uuid[])
"""

PASSAGEM_MAIS_RECENTE = """
SELECT DISTINCT ON (p.lead_id) p.lead_id::text AS lead_id, p.destino_rotulo, p.resumo, p.quando
  FROM passagens_do_atendimento p
 WHERE p.lead_id = ANY(%s::uuid[])
 ORDER BY p.lead_id, p.quando DESC
"""

ITENS = """
SELECT o.contato_id::text AS lead_id, i.oportunidade_id::text AS negocio, pr.nome, pr.valor, pr.ficha,
       pr.ficha_resumida->>'resumo' AS resumo,
       (SELECT string_agg(c.nome, ', ' ORDER BY c.nome)
          FROM produtos_categorias pc JOIN categorias c ON c.id = pc.categoria_id
         WHERE pc.produto_id = pr.id) AS categorias
  FROM itens_da_oportunidade i
  JOIN oportunidades o ON o.id = i.oportunidade_id
  JOIN produtos pr ON pr.id = i.produto_id
 WHERE o.contato_id = ANY(%s::uuid[])
 ORDER BY i.oportunidade_id, pr.nome
"""

#: Todas as consultas, para o teste conferir que nenhuma escreve.
TODAS = (NEGOCIOS, FASES, LEADS, HISTORICO, CONVERSAS, PASSAGENS, NINGUEM_ASSUMIU, TAREFAS, AGENDA,
         PERFIS, PASSAGEM_MAIS_RECENTE, ITENS)


async def ler(contexto, inicio: datetime, agora: datetime, frente: datetime) -> dict[str, list[dict[str, Any]]]:
    """A base do período: o que foi registrado de `inicio` até `agora`, e a agenda até `frente`."""
    consultar = contexto.consultar
    dados = {
        "negocios": await consultar(NEGOCIOS, inicio, inicio, inicio),
        "fases": await consultar(FASES),
        "leads": await consultar(LEADS, inicio, agora),
        "historico": await consultar(HISTORICO, inicio, agora, constantes.LINHAS_DO_PERIODO + 1),
        "conversas": await consultar(CONVERSAS, inicio, agora, inicio, agora, inicio, inicio),
        "passagens": await consultar(PASSAGENS, inicio, agora),
        "ninguem_assumiu": await consultar(NINGUEM_ASSUMIU, inicio, agora),
        "tarefas": await consultar(TAREFAS, inicio, agora),
        "agenda": await consultar(AGENDA, inicio, frente),
    }
    _conferir_tamanho(dados)
    return dados


async def ler_detalhe(contexto, lead_ids: list[str]) -> dict[str, list[dict[str, Any]]]:
    """O detalhe dos clientes que entram no bloco; sem cliente, nenhuma consulta."""
    if not lead_ids:
        return {"perfis": [], "passagens": [], "itens": []}
    return {
        "perfis": await contexto.consultar(PERFIS, lead_ids),
        "passagens": await contexto.consultar(PASSAGEM_MAIS_RECENTE, lead_ids),
        "itens": await contexto.consultar(ITENS, lead_ids),
    }


def _conferir_tamanho(dados: dict[str, list[dict[str, Any]]]) -> None:
    for nome, linhas in dados.items():
        if len(linhas) > constantes.LINHAS_DO_PERIODO:
            raise RuntimeError(
                f"o período tem mais de {constantes.LINHAS_DO_PERIODO} registros em {nome}; o resumo não sai pela metade"
            )
