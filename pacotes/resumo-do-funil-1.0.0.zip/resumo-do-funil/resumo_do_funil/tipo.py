"""
OS GRUPOS DE NEGÓCIO (story 42.1) — o funil não tem uma coluna que diga o tipo do negócio. Os grupos vêm do campo
`tipos_de_negocio` (uma linha por grupo: `Nome: palavra, palavra`). Padrão vazio = sem grupos, e o resumo não fala de tipo.

O negócio cai num grupo pela PRIMEIRA pista que apontar para um grupo só, nesta ordem:

    1. a equipe (o destino) da última passagem do atendimento
    2. o título e a intenção do negócio
    3. o nome e a ficha do item do catálogo ligado a ele

Pista que bate em mais de um grupo não decide (passa à próxima). Sem pista nenhuma: "sem tipo", nunca um palpite.
"""

from __future__ import annotations

from typing import Any

from .textos import sem_acento, tem

SEM_TIPO = "sem tipo"
PISTAS = ("pista_equipe", "pista_titulo", "pista_item")


def grupos(texto: Any) -> list[tuple[str, list[str]]]:
    """ "Nome: palavra, palavra" por linha → [("Nome", ["palavra", "palavra"])]. Linha sem ":" ou sem palavra não vale."""
    saida = []
    for linha in str(texto or "").splitlines():
        nome, sinal, resto = linha.partition(":")
        palavras_do_grupo = [sem_acento(p).strip() for p in resto.split(",") if p.strip()]
        if sinal and nome.strip() and palavras_do_grupo:
            saida.append((nome.strip(), palavras_do_grupo))
    return saida


def do_negocio(negocio: dict[str, Any], lista_de_grupos: list[tuple[str, list[str]]]) -> str:
    """O grupo do negócio pela primeira pista que aponta para um grupo só; sem pista, "sem tipo"."""
    for chave in PISTAS:
        achados = [nome for nome, palavras in lista_de_grupos if tem(negocio.get(chave), palavras)]
        if len(achados) == 1:
            return achados[0]
    return SEM_TIPO


def contagem(tipos: list[str], lista_de_grupos: list[tuple[str, list[str]]]) -> str:
    """["Grupo A", "Grupo B", "Grupo A"] → "grupo a 2, grupo b 1" (só os que têm). Sem grupos, nada: o resumo não fala de tipo."""
    if not lista_de_grupos:
        return ""
    nomes = [nome for nome, _ in lista_de_grupos] + [SEM_TIPO]
    partes = [f"{nome.lower()} {tipos.count(nome)}" for nome in nomes if tipos.count(nome)]
    return ", ".join(partes)
