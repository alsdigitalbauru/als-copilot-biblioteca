"""
A FREQUÊNCIA DO RESUMO (story 42.1) — o dono escolhe diária, semanal ou mensal. O gatilho é diário (20h); o código
decide se hoje é dia de mandar e qual período ler. Sem banco e sem IA.

    diária     todo dia; o período é hoje (de 00:00 até a hora da rodada); o "amanhã" é o dia seguinte inteiro
    semanal    no dia da semana escolhido; o período são os últimos 7 dias, contando hoje; o "amanhã" vira "próximos 7 dias"
    mensal     no dia do mês escolhido (31 = o último dia de cada mês); o período é o mês corrente, do dia 1 até agora
"""

from __future__ import annotations

import calendar
from datetime import datetime, timedelta
from typing import Any

from . import constantes, textos
from .relogio import FUSO

FREQUENCIAS = ("diaria", "semanal", "mensal")
VALORES_DOS_DIAS = ("segunda", "terca", "quarta", "quinta", "sexta", "sabado", "domingo")
DIA_DO_MES_MAXIMO = 31


def frequencia(campos: dict[str, Any]) -> str:
    valor = str(campos.get("frequencia") or constantes.FREQUENCIA)
    return valor if valor in FREQUENCIAS else constantes.FREQUENCIA


def _dia_da_semana(campos: dict[str, Any]) -> int:
    valor = str(campos.get("dia_da_semana") or "")
    if valor not in VALORES_DOS_DIAS:
        valor = constantes.DIA_DA_SEMANA
    return VALORES_DOS_DIAS.index(valor)


def dia_do_mes(campos: dict[str, Any]) -> int:
    try:
        dia = int(campos.get("dia_do_mes", constantes.DIA_DO_MES))
    except (TypeError, ValueError):
        dia = constantes.DIA_DO_MES
    return min(max(dia, 1), DIA_DO_MES_MAXIMO)


def eh_dia_de_mandar(agora: datetime, campos: dict[str, Any]) -> bool:
    local = agora.astimezone(FUSO)
    freq = frequencia(campos)
    if freq == "semanal":
        return local.weekday() == _dia_da_semana(campos)
    if freq == "mensal":
        ultimo = calendar.monthrange(local.year, local.month)[1]
        return local.day == min(dia_do_mes(campos), ultimo)
    return True


def motivo_de_pular(campos: dict[str, Any]) -> str:
    """Por que hoje não manda ("semanal, sexta"), em uma frase para o registro."""
    if frequencia(campos) == "mensal":
        return f"hoje não é dia de mandar: mensal, dia {dia_do_mes(campos)}"
    return f"hoje não é dia de mandar: semanal, {textos.DIAS_DA_SEMANA[_dia_da_semana(campos)]}"


def inicio_de_hoje(agora: datetime) -> datetime:
    return agora.astimezone(FUSO).replace(hour=0, minute=0, second=0, microsecond=0)


def inicio_de_amanha(agora: datetime) -> datetime:
    return inicio_de_hoje(agora) + timedelta(days=1)


def inicio_do_periodo(agora: datetime, freq: str) -> datetime:
    hoje = inicio_de_hoje(agora)
    if freq == "semanal":
        return hoje - timedelta(days=6)
    if freq == "mensal":
        return hoje.replace(day=1)
    return hoje


def fim_da_frente(agora: datetime, freq: str) -> datetime:
    """Até onde o "amanhã" olha: o dia seguinte (diária) ou os 7 dias seguintes (semanal e mensal)."""
    return inicio_de_amanha(agora) + timedelta(days=1 if freq == "diaria" else 7)


def quando(freq: str) -> str:
    """O advérbio das frases do período: "Hoje não houve…", "Concluídas hoje", "Total fechado no período"."""
    return "hoje" if freq == "diaria" else "no período"


def quando_frente(freq: str) -> str:
    return "amanhã" if freq == "diaria" else "nos próximos 7 dias"


def de_frente(freq: str) -> str:
    return "de amanhã" if freq == "diaria" else "dos próximos 7 dias"


def para_frente(freq: str) -> str:
    return "para amanhã" if freq == "diaria" else "para os próximos 7 dias"


def cabeca_da_frente(freq: str) -> str:
    return "Amanhã" if freq == "diaria" else "Próximos 7 dias"


def desde(agora: datetime, freq: str) -> str:
    return "00:00" if freq == "diaria" else textos.dia(inicio_do_periodo(agora, freq))


def titulo(agora: datetime, freq: str) -> str:
    if freq == "semanal":
        return f"Resumo da semana — {textos.intervalo(inicio_do_periodo(agora, freq), agora)}"
    if freq == "mensal":
        return f"Resumo do mês — {textos.rotulo_do_mes(agora)}"
    return f"Resumo do dia — {textos.dia_da_semana(agora)}"
