"""
OS COMPROMISSOS ESCRITOS À MÃO (campo `compromissos_avulsos`): um por linha.

    17/11 08:00 Nome                     um dia só («17/11/2026 8h30 Nome» também vale; sem ano, vale o dia que cair na janela)
    toda quarta 09:00 Nome desde 25/11   toda semana nesse dia; «desde», «até» e «exceto 10/12, 17/12» são opcionais

Linha que não se entende não derruba a rodada: volta em `erros`.
"""

from __future__ import annotations

import re
import unicodedata
from datetime import date, datetime, time, timedelta

from .relogio import FUSO

HORA = r"(\d{1,2})(?::(\d{2})|h(\d{2})?)"
DATA = r"(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?"
UMA_VEZ = re.compile(rf"^{DATA}\s+(?:às\s+)?{HORA}\s*[-–—:]?\s*(.+)$", re.IGNORECASE)
TODA_SEMANA = re.compile(rf"^todas?\s+(?:as\s+|os\s+|a\s+|o\s+)?([a-zçáéíóú]+?)(?:-feiras?)?\s+(?:às\s+)?{HORA}\s*[-–—:]?\s*(.+)$", re.IGNORECASE)
DESDE = re.compile(rf"\s+desde\s+{DATA}", re.IGNORECASE)
ATE = re.compile(rf"\s+até\s+{DATA}", re.IGNORECASE)
EXCETO = re.compile(rf"\s+exceto\s+({DATA}(?:\s*,\s*{DATA})*)", re.IGNORECASE)
SEMANA = {"segunda": 0, "terca": 1, "quarta": 2, "quinta": 3, "sexta": 4, "sabado": 5, "domingo": 6}


def _sem_acento(texto: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", texto.lower()) if unicodedata.category(c) != "Mn")


def _data(dia: str, mes: str, ano: str | None, referencia: int) -> date:
    inteiro = (int(ano) + (2000 if len(ano) == 2 else 0)) if ano else referencia
    return date(inteiro, int(mes), int(dia))


def _hora(h: str, a: str | None, b: str | None) -> time:
    return time(int(h), int(a or b or 0))


def _item(titulo: str, dia: date, hora: time) -> dict:
    return {
        "titulo": titulo.strip(),
        "inicio": datetime.combine(dia, hora, tzinfo=FUSO),
        "fim": None,
        "situacao": "confirmado",
        "tipo": "compromisso",
        "fonte": "avulso",
    }


def _recorrente(achou: re.Match, dias: list[date]) -> list[dict]:
    nome, h, ma, mb, resto = achou.groups()
    if _sem_acento(nome) not in SEMANA:
        raise ValueError("dia da semana desconhecido")
    ano = dias[0].year
    desde = DESDE.search(resto)
    ate = ATE.search(resto)
    exceto = EXCETO.search(resto)
    inicio = _data(*desde.groups(), ano) if desde else None
    fim = _data(*ate.groups(), ano) if ate else None
    fora = {_data(d, m, a, ano) for d, m, a in re.findall(DATA, exceto.group(1))} if exceto else set()
    titulo = resto
    for pedaco in (desde, ate, exceto):
        if pedaco:
            titulo = titulo.replace(pedaco.group(0), "")
    if not titulo.strip():
        raise ValueError("sem título")
    hora = _hora(h, ma, mb)
    return [
        _item(titulo, d, hora)
        for d in dias
        if d.weekday() == SEMANA[_sem_acento(nome)] and (not inicio or d >= inicio) and (not fim or d <= fim) and d not in fora
    ]


def _uma_vez(achou: re.Match, dias: list[date]) -> list[dict]:
    dia, mes, ano, h, ma, mb, titulo = achou.groups()
    hora = _hora(h, ma, mb)
    date(2024, int(mes), int(dia))  # confere que o dia existe (29/02 vale)
    inteiro = (int(ano) + (2000 if len(ano) == 2 else 0)) if ano else None
    return [_item(titulo, d, hora) for d in dias if d.day == int(dia) and d.month == int(mes) and inteiro in (None, d.year)]


def ler(texto: str, dias: list[date]) -> tuple[list[dict], list[str]]:
    itens: list[dict] = []
    erros: list[str] = []
    for bruta in (texto or "").splitlines():
        linha = bruta.strip()
        if not linha:
            continue
        try:
            if achou := TODA_SEMANA.match(linha):
                itens += _recorrente(achou, dias)
            elif achou := UMA_VEZ.match(linha):
                itens += _uma_vez(achou, dias)
            else:
                erros.append(linha)
        except ValueError:
            erros.append(linha)
    return itens, erros


def titulos(texto: str) -> list[str]:
    """Os títulos de TODAS as linhas, em qualquer dia: serve para não repetir um lembrete sem data que já tem dia marcado."""
    saida = []
    for linha in (texto or "").splitlines():
        achou = TODA_SEMANA.match(linha.strip()) or UMA_VEZ.match(linha.strip())
        if achou:
            saida.append(achou.groups()[-1])
    return saida
