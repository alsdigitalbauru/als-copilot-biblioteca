"""
A AGENDA: junta as fontes (sistema, lembretes, escritos à mão), tira a repetição e aponta conflitos e intervalos apertados.
Sem banco e sem IA: só conta e compara.
"""

from __future__ import annotations

import re
import unicodedata
from datetime import date, datetime, timedelta
from typing import Any

from . import constantes
from .relogio import FUSO

PALAVRAS_FRACAS = {"para", "com", "dos", "das", "pela", "pelo", "uma", "umas", "este", "esta", "essa", "esse"}


def _palavras(titulo: str) -> set[str]:
    sem_acento = unicodedata.normalize("NFD", titulo.lower())
    limpo = "".join(c for c in sem_acento if unicodedata.category(c) != "Mn")
    return {p for p in re.findall(r"[a-z0-9]{4,}", limpo) if p not in PALAVRAS_FRACAS}


def _mesmo_compromisso(a: dict, b: dict) -> bool:
    if a["inicio"].replace(second=0, microsecond=0) != b["inicio"].replace(second=0, microsecond=0):
        return False
    return bool(_palavras(a["titulo"]) & _palavras(b["titulo"]))


def dias_da_janela(primeiro: date, quantos: int = constantes.DIAS_DA_JANELA) -> list[date]:
    return [primeiro + timedelta(days=i) for i in range(quantos)]


def _parecidos(a: str, b: str) -> bool:
    """Dois títulos que falam da mesma coisa: duas palavras em comum (uma só, se um deles só tem uma)."""
    pa, pb = _palavras(a), _palavras(b)
    return bool(pa and pb) and len(pa & pb) >= min(2, len(pa), len(pb))


def montar(
    dados: dict[str, list[dict[str, Any]]], avulsos: list[dict], dias: list[date], inicio: datetime, titulos_marcados: list[str] | None = None
) -> dict[str, Any]:
    """Devolve `{"por_dia": {date: [compromissos]}, "sem_data": [textos]}`."""
    do_sistema = []
    for e in dados["eventos"]:
        do_sistema.append(
            {
                "titulo": (e["titulo"] or "").strip(),
                "inicio": e["inicio_em"].astimezone(FUSO),
                "fim": e["fim_em"].astimezone(FUSO) if e.get("fim_em") else None,
                "situacao": e.get("situacao") or "confirmado",
                "tipo": "compromisso",
                "fonte": "sistema",
            }
        )
    por_dia: dict[date, list[dict]] = {d: [] for d in dias}
    sem_data: list[str] = []
    itens = list(do_sistema)
    for a in avulsos:
        if not any(_mesmo_compromisso(a, s) for s in do_sistema):
            itens.append(a)
    for lembrete in dados["lembretes"]:
        quando = lembrete.get("lembrete_em") or lembrete.get("prazo_em")
        titulo = (lembrete["titulo"] or "").strip()
        # Lembrete sem data que já tem dia marcado nos compromissos escritos à mão não se repete na lista.
        if any(_parecidos(titulo, t) for t in [*(titulos_marcados or []), *(i["titulo"] for i in itens)]):
            continue
        if quando is None:
            sem_data.append(titulo)
            continue
        quando = quando.astimezone(FUSO)
        if quando < inicio:
            sem_data.append(f"{titulo} (venceu em {quando:%d/%m})")
        elif quando.date() in por_dia:
            itens.append(
                {"titulo": titulo, "inicio": quando, "fim": None, "situacao": "confirmado", "tipo": "lembrete", "fonte": "lembrete"}
            )
    for item in itens:
        if item["inicio"].date() in por_dia:
            por_dia[item["inicio"].date()].append(item)
    for dia in por_dia:
        por_dia[dia].sort(key=lambda i: (i["inicio"], i["tipo"] != "compromisso"))
        _apontar(por_dia[dia])
    return {"por_dia": por_dia, "sem_data": sem_data}


def _fim(item: dict) -> datetime:
    return item["fim"] or item["inicio"] + timedelta(minutes=constantes.DURACAO_PADRAO)


def _apontar(itens: list[dict]) -> None:
    """Põe em cada item `conflitos` (quem se sobrepõe) e `apertado` (o seguinte começa logo depois). Só compromissos."""
    for item in itens:
        item["conflitos"] = []
        item["apertado"] = None
    reais = [i for i in itens if i["tipo"] == "compromisso"]
    for n, a in enumerate(reais):
        for b in reais[n + 1 :]:
            if b["inicio"] < _fim(a):
                a["conflitos"].append(b)
                b["conflitos"].append(a)
        seguinte = next((b for b in reais[n + 1 :] if all(b is not c for c in a["conflitos"])), None)
        if seguinte is not None:
            folga = (seguinte["inicio"] - _fim(a)).total_seconds() / 60
            if folga < constantes.INTERVALO_APERTADO:
                a["apertado"] = (seguinte, int(folga))


def tem_compromisso_cedo(agenda: dict[str, Any], dia: date, limite) -> bool:
    return any(i["tipo"] == "compromisso" and i["inicio"].time() <= limite for i in agenda["por_dia"].get(dia, []))
