"""
O AVISO À ALS QUANDO QUEBRA — vai a QUEM CONSERTA (`contexto.avisar(..., para="als")`), não à pessoa da agenda.
UM AVISO POR PROBLEMA, NÃO UM POR RODADA: o que já foi avisado fica no estado e não se repete; quando passa, sai um
"voltou ao normal". Aviso que não saiu NÃO é marcado como avisado — a rodada seguinte tenta de novo.
"""

from __future__ import annotations

TITULO = "Agenda da semana"

PROBLEMAS = {
    "leitura": "a leitura do banco falhou (uma tabela ou coluna do sistema pode ter mudado de versão)",
    "pessoa": "o e-mail do campo «E-mail da pessoa dona da agenda» não é de nenhum usuário",
    "aviso": "o envio da agenda não saiu",
    "avulsos": "há linhas em «Compromissos escritos à mão» que não consegui entender",
}


async def tratar(contexto, problemas: dict[str, str], *, rodada_completa: bool) -> None:
    estado = await contexto.estado.ler()
    avisados: dict[str, str] = dict(estado.get("avisados") or {})
    mudou = False
    for codigo, detalhe in problemas.items():
        if codigo in avisados:
            continue
        texto = (
            f"A automação da agenda da semana precisa de atenção: {PROBLEMAS.get(codigo, codigo)}.\nDetalhe: {detalhe}"
        )
        try:
            await contexto.avisar(texto, para="als", titulo=TITULO)
        except Exception as erro:  # noqa: BLE001
            contexto.registrar(f"o aviso à ALS não saiu ({erro}); tento de novo na próxima rodada")
            continue
        avisados[codigo] = detalhe
        mudou = True
    if rodada_completa:
        for codigo in [c for c in avisados if c not in problemas]:
            try:
                await contexto.avisar(
                    f"Voltou ao normal: a agenda da semana — {PROBLEMAS.get(codigo, codigo)} — funcionou de novo.",
                    para="als",
                    titulo=TITULO,
                )
            except Exception as erro:  # noqa: BLE001
                contexto.registrar(f"o aviso de 'voltou ao normal' não saiu ({erro})")
                continue
            del avisados[codigo]
            mudou = True
    if mudou:
        estado = await contexto.estado.ler()
        estado["avisados"] = avisados
        await contexto.estado.gravar(estado)
