"""O QUE A AUTOMAÇÃO DIZ: o dia da semana, a hora e a mensagem da agenda."""

from __future__ import annotations

from datetime import date, datetime

from . import constantes

SEMANA = ["segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado", "domingo"]


def dia_da_semana(dia: date) -> str:
    return SEMANA[dia.weekday()]


def dia_curto(dia: date) -> str:
    return f"{SEMANA[dia.weekday()].split('-')[0]}, {dia:%d/%m}"


def hora(momento: datetime) -> str:
    return f"{momento:%H:%M}"


def _linha(item: dict) -> str:
    quando = hora(item["inicio"]) + (f"–{hora(item['fim'])}" if item["fim"] else "")
    marcas = ""
    if item["tipo"] == "lembrete":
        marcas += "🔔 Lembrete: "
    extra = ""
    if item["situacao"] in ("pendente", "aguardando_confirmacao"):
        extra = " _(a confirmar)_"
    return f"• {quando} — {marcas}{item['titulo']}{extra}"


def _avisos_do_dia(itens: list[dict]) -> list[str]:
    linhas: list[str] = []
    vistos: set[tuple[int, int]] = set()
    for n, a in enumerate(itens):
        for b in a.get("conflitos", []):
            par = tuple(sorted((id(a), id(b))))
            if par in vistos:
                continue
            vistos.add(par)  # type: ignore[arg-type]
            linhas.append(f"⚠️ Conflito: {hora(a['inicio'])} {a['titulo']} × {hora(b['inicio'])} {b['titulo']}")
        if a.get("apertado"):
            seguinte, folga = a["apertado"]
            linhas.append(
                f"⏱️ Intervalo apertado ({folga} min): {a['titulo']} → {hora(seguinte['inicio'])} {seguinte['titulo']}"
            )
    return linhas


def blocos(agenda: dict, hoje: date) -> list[str]:
    saida: list[str] = []
    for dia, itens in agenda["por_dia"].items():
        rotulo = " (hoje)" if dia == hoje else " (amanhã)" if (dia - hoje).days == 1 else ""
        titulo = f"*{dia_da_semana(dia).capitalize()}, {dia:%d/%m}{rotulo}*"
        corpo = [_linha(i) for i in itens] or ["Nada marcado."]
        saida.append("\n".join([titulo, *corpo, *_avisos_do_dia(itens)]))
    if agenda["sem_data"]:
        saida.append("\n".join(["🔔 *Lembretes para agendar (sem data)*", *[f"• {t}" for t in agenda["sem_data"]]]))
    return saida


def _cortar(bloco: str) -> list[str]:
    """Um dia que sozinho passa do teto (centenas de compromissos) é cortado entre linhas."""
    if len(bloco) <= constantes.MAXIMO_DO_TEXTO - 100:
        return [bloco]
    titulo, *linhas = bloco.split("\n")
    pedacos: list[str] = []
    atual = titulo
    for linha in linhas:
        if len(atual) + 1 + len(linha) > constantes.MAXIMO_DO_TEXTO - 100:
            pedacos.append(atual)
            atual = f"{titulo} _(continua)_"
        atual += "\n" + linha
    pedacos.append(atual)
    return pedacos


def para_email(texto: str) -> str:
    """O e-mail sai em texto puro: sem as marcas de negrito e de itálico do WhatsApp."""
    return texto.replace("*", "").replace("_(a confirmar)_", "(a confirmar)")


def cabecalho(agenda: dict, hoje: date) -> str:
    dias = list(agenda["por_dia"])
    if len(dias) == 1:
        quando = "de amanhã" if (dias[0] - hoje).days == 1 else "de hoje"
        return f"📅 *Agenda {quando}* — {dia_curto(dias[0])}"
    return f"📅 *Agenda da semana* — {dia_curto(dias[0])} a {dia_curto(dias[-1])}"


def assunto(agenda: dict, hoje: date) -> str:
    return para_email(cabecalho(agenda, hoje)).replace("📅 ", "")


def mensagens(agenda: dict, hoje: date) -> list[str]:
    """A agenda em um ou mais textos, cortando entre blocos (nunca no meio de um dia)."""
    cabecalho_da_agenda = cabecalho(agenda, hoje)
    textos: list[str] = []
    atual = cabecalho_da_agenda
    for bloco in [p for b in blocos(agenda, hoje) for p in _cortar(b)]:
        if len(atual) + 2 + len(bloco) > constantes.MAXIMO_DO_TEXTO and atual:
            textos.append(atual)
            atual = ""
        atual = f"{atual}\n\n{bloco}" if atual else bloco
    textos.append(atual)
    return textos
