"""
A LEITURA — TODO o SQL do pacote, e só SELECT (o teste confere): a automação nunca escreve no sistema.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

PESSOA = """
SELECT id::text AS id, nome, email
  FROM usuarios
 WHERE lower(email) = lower(%s) AND excluido_em IS NULL
 LIMIT 1
"""

#: A agenda da pessoa: o que ela marcou, os negócios dela e a agenda solta do agente (marcada pela conversa, sem negócio nem contato).
EVENTOS = """
SELECT e.titulo, e.inicio_em, e.fim_em, e.situacao
  FROM eventos_agenda e
  LEFT JOIN oportunidades o ON o.id = e.oportunidade_id
 WHERE e.inicio_em >= %s AND e.inicio_em < %s
   AND e.situacao IS DISTINCT FROM 'cancelado'
   AND (e.criado_por_usuario_id = %s::uuid
        OR o.responsavel_id = %s::uuid
        OR (e.criado_por_usuario_id IS NULL AND e.oportunidade_id IS NULL AND e.contato_id IS NULL))
 ORDER BY e.inicio_em
"""

#: Os lembretes em aberto da pessoa que ainda não viraram compromisso na agenda.
LEMBRETES = """
SELECT t.titulo, t.lembrete_em, t.prazo_em
  FROM tarefas t
 WHERE t.lembrete AND t.status NOT IN ('concluida', 'cancelada')
   AND (t.criado_por_usuario_id = %s::uuid OR t.responsavel_usuario_id = %s::uuid)
   AND NOT EXISTS (SELECT 1 FROM eventos_agenda e
                    WHERE e.tarefa_id = t.id AND e.situacao IS DISTINCT FROM 'cancelado' AND e.inicio_em >= %s)
 ORDER BY t.criado_em
"""

#: O e-mail que a instalação já tem configurado (Configurações → E-mail): quem manda a agenda por e-mail usa o mesmo.
EMAIL_DA_INSTALACAO = """
SELECT servidor, porta, seguranca, usuario, senha_cifrada, remetente_email, remetente_nome
  FROM configuracao_de_email
 WHERE id AND ligado
"""

#: Todas as consultas, para o teste conferir que nenhuma escreve.
TODAS = (PESSOA, EVENTOS, LEMBRETES, EMAIL_DA_INSTALACAO)


async def pessoa(contexto, email: str) -> dict[str, Any] | None:
    linhas = await contexto.consultar(PESSOA, email)
    return linhas[0] if linhas else None


async def ler(contexto, pessoa_id: str, inicio: datetime, fim: datetime) -> dict[str, list[dict[str, Any]]]:
    return {
        "eventos": await contexto.consultar(EVENTOS, inicio, fim, pessoa_id, pessoa_id),
        "lembretes": await contexto.consultar(LEMBRETES, pessoa_id, pessoa_id, inicio),
    }
