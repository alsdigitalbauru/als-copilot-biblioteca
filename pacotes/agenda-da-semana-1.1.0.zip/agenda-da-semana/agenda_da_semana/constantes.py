"""OS NÚMEROS DA AGENDA DA SEMANA. Não importa ninguém — os outros arquivos do pacote leem daqui."""

#: O teto do texto de um aviso (`contexto.avisar` aceita até 4.000 caracteres), com folga.
MAXIMO_DO_TEXTO = 3900
#: Quantos dias a agenda mostra, contando o primeiro.
DIAS_DA_JANELA = 7
#: Compromisso sem hora de fim ocupa tantos minutos (para achar conflito).
DURACAO_PADRAO = 60
#: Entre um compromisso e o seguinte, menos que isto (em minutos) é intervalo apertado.
INTERVALO_APERTADO = 30
#: A rodada que começa a partir desta hora é a da véspera (a das 21h); antes dela é a da manhã.
HORA_DA_VESPERA = 12
#: Padrão do campo "compromisso cedo até as".
HORA_CEDO = "08:00"
#: O número do `automacao.yaml` — o teste o confere contra o arquivo.
PRAZO_DA_RODADA = 120
