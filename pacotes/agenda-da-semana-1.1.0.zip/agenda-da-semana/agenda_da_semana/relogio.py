"""O RELÓGIO DA RODADA — num arquivo só, para o teste poder trocá-lo (`relogio.agora = …`)."""

from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo

FUSO = ZoneInfo("America/Sao_Paulo")


def agora() -> datetime:
    return datetime.now(FUSO)
