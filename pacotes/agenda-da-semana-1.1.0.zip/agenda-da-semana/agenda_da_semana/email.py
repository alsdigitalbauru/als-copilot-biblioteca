"""
O E-MAIL DA AGENDA: manda pelo servidor de e-mail que a instalação já configurou (Configurações → E-mail), lido do banco, com a
senha aberta pelo cofre só na memória da rodada. Nenhuma rota nova no Als Copilot e nenhuma senha escrita no pacote.
Vai só ao endereço pedido: a cópia fixa da instalação NÃO entra (a agenda é de uma pessoa).
"""

from __future__ import annotations

import asyncio
import smtplib
import ssl
from email.message import EmailMessage
from email.utils import formataddr

from . import leitura

ESPERA = 20


class EmailNaoConfigurado(RuntimeError):
    """A instalação não tem e-mail ligado, ou a senha dele não abre."""


def _abrir_senha(cifrada: str | None) -> str | None:
    if not cifrada:
        return None
    from receptor import cofre  # o receptor já está no caminho da rodada

    try:
        senha = cofre.decifrar(cifrada)
    except Exception:  # noqa: BLE001 — chave-mestra ausente ou trocada
        senha = None
    if senha is None:
        raise EmailNaoConfigurado("a senha do e-mail da instalação não abre (a chave-mestra mudou?)")
    return senha


def _enviar(config: dict, senha: str | None, para: str, assunto: str, texto: str) -> None:
    mensagem = EmailMessage()
    mensagem["From"] = formataddr((config.get("remetente_nome") or "", config["remetente_email"]))
    mensagem["To"] = para
    mensagem["Subject"] = assunto
    mensagem.set_content(texto)
    seguranca = config.get("seguranca") or "tls"
    if seguranca == "ssl":
        servidor: smtplib.SMTP = smtplib.SMTP_SSL(config["servidor"], config["porta"], timeout=ESPERA, context=ssl.create_default_context())
    else:
        servidor = smtplib.SMTP(config["servidor"], config["porta"], timeout=ESPERA)
    try:
        if seguranca == "tls":
            servidor.starttls(context=ssl.create_default_context())
        if config.get("usuario"):
            servidor.login(config["usuario"], senha or "")
        servidor.send_message(mensagem)
    finally:
        try:
            servidor.quit()
        except smtplib.SMTPException:
            pass


async def enviar(contexto, para: str, assunto: str, texto: str) -> None:
    """Levanta `EmailNaoConfigurado` (frase em português) ou o erro do servidor, sem a senha."""
    linhas = await contexto.consultar(leitura.EMAIL_DA_INSTALACAO)
    if not linhas:
        raise EmailNaoConfigurado("esta instalação não tem o e-mail configurado e ligado")
    config = linhas[0]
    senha = _abrir_senha(config.get("senha_cifrada"))
    try:
        await asyncio.to_thread(_enviar, config, senha, para, assunto, texto)
    except smtplib.SMTPAuthenticationError:
        raise EmailNaoConfigurado("o servidor de e-mail recusou o usuário e a senha") from None
    except (smtplib.SMTPException, OSError) as erro:
        raise RuntimeError(f"o servidor de e-mail não entregou ({type(erro).__name__})") from None
