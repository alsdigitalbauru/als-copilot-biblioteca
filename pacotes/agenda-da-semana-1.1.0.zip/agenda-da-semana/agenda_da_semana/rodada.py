"""
A RODADA. Nenhuma IA.

    8h (manhã)            manda a agenda dos próximos 7 dias, começando hoje — a não ser que a das 21h de ontem já a tenha mandado
    21h (véspera)         se amanhã tem compromisso até a hora do campo, manda a agenda começando amanhã; senão, não faz nada
    "Rodar agora"         manda a agenda começando hoje, na hora, sem marcar nada
    a leitura quebrou     avisa a ALS, um aviso por problema; a pessoa não recebe agenda pela metade
"""

from __future__ import annotations

from datetime import datetime, time, timedelta
from typing import Any

from . import agenda, avisos, avulsos, constantes, leitura, relogio, textos
from . import email as envio_por_email
from .relogio import FUSO


def _hora_do_campo(valor: Any) -> time:
    texto = str(valor or constantes.HORA_CEDO).strip()
    try:
        h, m = texto.split(":")[:2]
        return time(int(h), int(m))
    except ValueError:
        return time(8, 0)


def _telefone(valor: Any) -> str:
    digitos = "".join(c for c in str(valor or "") if c.isdigit())
    if digitos and len(digitos) <= 11:
        digitos = "55" + digitos
    return digitos


async def rodar(contexto) -> dict[str, Any]:
    agora = relogio.agora()
    hoje = agora.astimezone(FUSO).date()
    estado = await contexto.estado.ler()
    manual = contexto.gatilho == "manual"
    vespera = not manual and agora.hour >= constantes.HORA_DA_VESPERA
    primeiro = hoje + timedelta(days=1) if vespera else hoje

    if not manual and not vespera:
        if estado.get("antecipado_para") == hoje.isoformat():
            return {"situacao": "ok", "resumo": "A agenda de hoje já saiu ontem às 21h; nada a fazer."}
        if estado.get("enviado_em") == hoje.isoformat():
            return {"situacao": "ok", "resumo": "A agenda de hoje já saiu; nada a fazer até amanhã."}
    if vespera and estado.get("antecipado_para") == primeiro.isoformat():
        return {"situacao": "ok", "resumo": "A agenda de amanhã já saiu; nada a fazer."}

    por_email = str(contexto.campos.get("entrega") or "canal") == "email"
    quantos = 1 if str(contexto.campos.get("janela") or "semana") == "dia" else constantes.DIAS_DA_JANELA
    dias = agenda.dias_da_janela(primeiro, quantos)
    inicio = datetime.combine(dias[0], time(0, 0), tzinfo=FUSO)
    fim = datetime.combine(dias[-1] + timedelta(days=1), time(0, 0), tzinfo=FUSO)
    email = str(contexto.campos.get("email_da_pessoa") or "").strip()
    try:
        pessoa = await leitura.pessoa(contexto, email) if email else None
        if pessoa is None:
            detalhe = f"«{email}» não foi achado" if email else "o campo está vazio"
            await avisos.tratar(contexto, {"pessoa": detalhe}, rodada_completa=False)
            return {"situacao": "erro", "resumo": f"Não achei a pessoa dona da agenda: {detalhe}."}
        dados = await leitura.ler(contexto, pessoa["id"], inicio, fim)
    except Exception as erro:  # noqa: BLE001 — a pessoa não recebe agenda pela metade; a ALS é avisada
        contexto.registrar(f"a leitura do banco parou: {erro}")
        await avisos.tratar(contexto, {"leitura": str(erro)[:300]}, rodada_completa=False)
        return {"situacao": "erro", "resumo": f"Não consegui ler a agenda: {erro}"}

    escritos, entendidos = avulsos.ler(str(contexto.campos.get("compromissos_avulsos") or ""), dias)
    problemas = {"avulsos": " | ".join(entendidos)[:300]} if entendidos else {}
    quadro = agenda.montar(dados, escritos, dias, inicio, avulsos.titulos(str(contexto.campos.get("compromissos_avulsos") or "")))

    if vespera and not agenda.tem_compromisso_cedo(quadro, primeiro, _hora_do_campo(contexto.campos.get("hora_cedo"))):
        await avisos.tratar(contexto, problemas, rodada_completa=True)
        return {"situacao": "ok", "resumo": "Nenhum compromisso cedo amanhã; a agenda sai às 8h."}

    textos_da_agenda = textos.mensagens(quadro, hoje)
    telefone = _telefone(contexto.campos.get("telefone"))
    destino = str(contexto.campos.get("email_de_destino") or "").strip() or str(pessoa.get("email") or "")
    try:
        if por_email:
            await envio_por_email.enviar(
                contexto, destino, textos.assunto(quadro, hoje), textos.para_email("\n\n".join(textos_da_agenda))
            )
        else:
            for texto in textos_da_agenda:
                if telefone:
                    await contexto.avisar(texto, para=telefone, titulo=avisos.TITULO)
                else:
                    await contexto.avisar(texto, titulo=avisos.TITULO)
    except Exception as erro:  # noqa: BLE001
        contexto.registrar(f"a agenda não saiu: {erro}")
        problemas["aviso"] = str(erro)[:300]
        await avisos.tratar(contexto, problemas, rodada_completa=False)
        return {"situacao": "erro", "resumo": f"A agenda não chegou: {erro}"}

    if not manual:
        estado = await contexto.estado.ler()
        if vespera:
            estado["antecipado_para"] = primeiro.isoformat()
        else:
            estado["enviado_em"] = hoje.isoformat()
        await contexto.estado.gravar(estado)
    await avisos.tratar(contexto, problemas, rodada_completa=True)
    quantos = sum(1 for itens in quadro["por_dia"].values() for i in itens)
    return {
        "situacao": "aviso" if entendidos else "ok",
        "resumo": (
            f"Agenda enviada ({'a da véspera, ' if vespera else ''}{quantos} item(ns), {len(quadro['sem_data'])} lembrete(s) sem data)."
            + (f" {len(entendidos)} linha(s) escritas à mão não entendidas." if entendidos else "")
        ),
    }
