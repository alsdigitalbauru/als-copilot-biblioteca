"""
AGENDA DA SEMANA — a porta. O código mora em `agenda_da_semana/`, um arquivo por função:

    constantes.py   os números (dias da janela, duração padrão, intervalo apertado, teto do texto)
    relogio.py      a hora de São Paulo (trocável no teste)
    textos.py       dia da semana, hora e a mensagem da agenda
    avulsos.py      lê a lista de compromissos escritos à mão
    leitura.py      TODO o SQL (só SELECT): a pessoa, os eventos e os lembretes
    agenda.py       junta as fontes, tira a repetição e aponta conflitos e intervalos apertados
    avisos.py       o aviso à ALS quando algo quebra, um por problema
    rodada.py       a rodada inteira

Uma aplicação independente (só lê o banco e avisa uma pessoa), com ZERO IA.
"""

from __future__ import annotations

from agenda_da_semana.rodada import rodar


async def executar(contexto):
    return await rodar(contexto)
